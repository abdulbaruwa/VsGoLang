// Type: NUnit.Framework.TestFixtureAttribute
// Assembly: nunit.framework, Version=2.5.7.10213, Culture=neutral, PublicKeyToken=96d09a1eb7f44a77
// Assembly location: C:\Work\Dyno\DynoFieldApp\Lib\NUnit-2.5.7.10213\bin\net-2.0\framework\nunit.framework.dll

using System;

namespace NUnit.Framework
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class TestFixtureAttribute : Attribute
    {
        public TestFixtureAttribute();
        public TestFixtureAttribute(params object[] arguments);
        public string Description { get; set; }
        public object[] Arguments { get; }
        public bool Ignore { get; set; }
        public string IgnoreReason { get; set; }
        public Type[] TypeArgs { get; set; }
    }
}
