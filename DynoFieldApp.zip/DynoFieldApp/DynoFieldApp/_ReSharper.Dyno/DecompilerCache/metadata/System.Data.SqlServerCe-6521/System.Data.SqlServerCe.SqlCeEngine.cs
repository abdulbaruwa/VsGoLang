// Type: System.Data.SqlServerCe.SqlCeEngine
// Assembly: System.Data.SqlServerCe, Version=4.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91
// Assembly location: C:\Work\Dyno\DynoFieldApp\Lib\SqlCE40\System.Data.SqlServerCe.dll

using System;
using System.Security;

namespace System.Data.SqlServerCe
{
    public sealed class SqlCeEngine : IDisposable
    {
        [SecurityTreatAsSafe]
        [SecurityCritical]
        public SqlCeEngine();

        public SqlCeEngine(string connectionString);
        public string LocalConnectionString { get; set; }

        #region IDisposable Members

        public void Dispose();

        #endregion

        ~SqlCeEngine();
        public void Compact(string connectionString);
        public void Shrink();
        public void Repair(string connectionString, RepairOption options);
        public bool Verify();
        public bool Verify(VerifyOption option);

        [SecurityCritical]
        [SecurityTreatAsSafe]
        public void CreateDatabase();

        public void Upgrade();
        public void Upgrade(string destConnectionString);
    }
}
