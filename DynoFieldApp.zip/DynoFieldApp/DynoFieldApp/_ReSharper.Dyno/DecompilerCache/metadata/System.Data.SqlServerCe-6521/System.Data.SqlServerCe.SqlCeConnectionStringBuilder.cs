// Type: System.Data.SqlServerCe.SqlCeConnectionStringBuilder
// Assembly: System.Data.SqlServerCe, Version=4.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91
// Assembly location: C:\Work\Dyno\DynoFieldApp\Lib\SqlCE40\System.Data.SqlServerCe.dll

using System.Collections;
using System.ComponentModel;
using System.Data.Common;

namespace System.Data.SqlServerCe
{
    [TypeConverter(typeof (SqlCeConnectionStringBuilder.SqlCeConnectionStringBuilderConverter))]
    [DefaultProperty("DataSource")]
    public sealed class SqlCeConnectionStringBuilder : DbConnectionStringBuilder
    {
        public SqlCeConnectionStringBuilder();
        public SqlCeConnectionStringBuilder(string connectionString);
        public override object this[string keyword] { get; set; }

        [DisplayName("Autoshrink Threshold")]
        [RefreshProperties(RefreshProperties.All)]
        public int AutoshrinkThreshold { get; set; }

        [Browsable(false)]
        [RefreshProperties(RefreshProperties.All)]
        [DisplayName("Case Sensitive")]
        public bool CaseSensitive { get; set; }

        [DisplayName("Data Source")]
        [RefreshProperties(RefreshProperties.All)]
        public string DataSource { get; set; }

        [DisplayName("Default Lock Escalation")]
        [RefreshProperties(RefreshProperties.All)]
        public int DefaultLockEscalation { get; set; }

        [DisplayName("Default Lock Timeout")]
        [RefreshProperties(RefreshProperties.All)]
        public int DefaultLockTimeout { get; set; }

        [Browsable(false)]
        [DisplayName("Encrypt Database")]
        [RefreshProperties(RefreshProperties.All)]
        public bool Encrypt { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [Browsable(false)]
        [DisplayName("Encryption Mode")]
        [TypeConverter(typeof (SqlCeConnectionStringBuilder.EncryptionModeConverter))]
        public string EncryptionMode { get; set; }

        [DisplayName("Enlist")]
        [RefreshProperties(RefreshProperties.All)]
        [Browsable(false)]
        public bool Enlist { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [Browsable(false)]
        [DisplayName("Mode")]
        public string FileMode { get; set; }

        [DisplayName("Flush Interval")]
        [RefreshProperties(RefreshProperties.All)]
        public int FlushInterval { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [Browsable(false)]
        [DisplayName("Locale Identifier")]
        public int InitialLcid { get; set; }

        [DisplayName("Max Buffer Size")]
        [RefreshProperties(RefreshProperties.All)]
        public int MaxBufferSize { get; set; }

        [DisplayName("Max Database Size")]
        [RefreshProperties(RefreshProperties.All)]
        public int MaxDatabaseSize { get; set; }

        [DisplayName("Password")]
        [RefreshProperties(RefreshProperties.All)]
        [PasswordPropertyText(true)]
        public string Password { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [DisplayName("Persist Security Info")]
        public bool PersistSecurityInfo { get; set; }

        [DisplayName("Temp File Max Size")]
        [RefreshProperties(RefreshProperties.All)]
        public int TempFileMaxSize { get; set; }

        [RefreshProperties(RefreshProperties.All)]
        [DisplayName("Temp File Directory")]
        public string TempFilePath { get; set; }

        public override ICollection Keys { get; }
        public override ICollection Values { get; }
        public override bool IsFixedSize { get; }
        public override void Clear();
        public override bool ContainsKey(string keyword);
        public override bool ShouldSerialize(string keyword);
        public override bool TryGetValue(string keyword, out object value);
        public override bool Remove(string keyword);
    }
}
