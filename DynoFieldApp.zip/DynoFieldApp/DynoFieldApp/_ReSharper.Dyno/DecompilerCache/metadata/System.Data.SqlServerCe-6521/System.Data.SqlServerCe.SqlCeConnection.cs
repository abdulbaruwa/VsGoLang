// Type: System.Data.SqlServerCe.SqlCeConnection
// Assembly: System.Data.SqlServerCe, Version=4.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91
// Assembly location: C:\Work\Dyno\DynoFieldApp\Lib\SqlCE40\System.Data.SqlServerCe.dll

using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Transactions;

namespace System.Data.SqlServerCe
{
    public sealed class SqlCeConnection : DbConnection
    {
        [SecurityTreatAsSafe]
        [SecurityCritical]
        public SqlCeConnection();

        public SqlCeConnection(string connectionString);

        public string DatabaseIdentifier { [SecurityTreatAsSafe, SecurityCritical]
        get; }

        public override string ConnectionString { get; set; }
        public override int ConnectionTimeout { get; }
        public override string Database { get; }
        public override string DataSource { get; }
        public override ConnectionState State { get; }
        public override string ServerVersion { get; }
        protected override DbProviderFactory DbProviderFactory { get; }

        [SecurityCritical]
        [SecurityTreatAsSafe]
        public override void EnlistTransaction(Transaction SysTrans);

        ~SqlCeConnection();
        public new void Dispose();

        [SecurityTreatAsSafe]
        [SecurityCritical]
        protected override void Dispose(bool disposing);

        public override void Close();

        [SecurityCritical]
        [SecurityTreatAsSafe]
        public List<KeyValuePair<string, string>> GetDatabaseInfo();

        [SecurityTreatAsSafe]
        [SecurityCritical]
        public new SqlCeTransaction BeginTransaction(System.Data.IsolationLevel isolationLevel);

        protected override DbTransaction BeginDbTransaction(System.Data.IsolationLevel isolationLevel);
        public new SqlCeTransaction BeginTransaction();
        public override void ChangeDatabase(string value);
        public override DataTable GetSchema();
        public override DataTable GetSchema(string collectionName);
        public override DataTable GetSchema(string collectionName, string[] restrictionValues);
        protected override DbCommand CreateDbCommand();
        public new SqlCeCommand CreateCommand();

        [SecurityCritical]
        [SecurityTreatAsSafe]
        public override void Open();

        public event SqlCeInfoMessageEventHandler InfoMessage;
        public event SqlCeFlushFailureEventHandler FlushFailure;
        public override event StateChangeEventHandler StateChange;
    }
}
