﻿using Pelican.QuestionTree.Model.Context;

namespace Pelican.Model
{
    public class Job
    {
        public string JobId { get; set; }

        private QuestionTreeContext QuestionTreeContext { get; set; } 
    }
}
