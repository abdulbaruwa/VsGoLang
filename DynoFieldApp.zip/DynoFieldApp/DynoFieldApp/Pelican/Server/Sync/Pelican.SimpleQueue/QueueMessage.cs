using System;

namespace Pelican.SimpleQueue
{
    public class QueueMessage<T>
    {
        public DateTime Added { get; set; }
        public DateTime? Retrieved { get; set; }
        public Decimal? Interval { get; set; }
        public DateTime? Schedule { get; set; }

        public QueueMessage(T Payload)
        {
            PayLoad = Payload;
        }

        public T PayLoad { get; set; }
        public Guid MessageId { get; set; }
    }
}