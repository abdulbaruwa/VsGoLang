﻿using System;

namespace Pelican.SimpleQueue
{
    public class PelicanSimpleQueueException : Exception
    {
        public PelicanSimpleQueueException(string targetDatabaseDirectoryNotFound)
            : base(targetDatabaseDirectoryNotFound)
        {
        }
    }
}