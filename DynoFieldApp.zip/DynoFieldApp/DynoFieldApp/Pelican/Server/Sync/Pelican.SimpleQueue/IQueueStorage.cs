using System;

namespace Pelican.SimpleQueue
{
    public interface IQueueStorage
    {
        void CreateIfRequired(string name, string queueType);
        void PushMessage<T>(QueueMessage<T> testMessageInstance);
        QueueMessage<T> GetMessage<T>();
        QueueMessage<T> GetMessageWithId<T>(Guid messageId);
        void DeleteMessage(Guid messageId);
        void ClearQueue();
        bool QueueDatabaseExists { get; }
        void DeleteDatabase();
    }
}