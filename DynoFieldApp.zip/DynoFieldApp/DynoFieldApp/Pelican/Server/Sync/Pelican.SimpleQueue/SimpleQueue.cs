using System;

namespace Pelican.SimpleQueue
{
    public class SimpleQueue<T>
    {
        private IQueueStorage _queueStorage;

        private SimpleQueue(string name, IQueueStorage queueStorage)
        {
            _queueStorage = queueStorage;
            _queueStorage.CreateIfRequired(name, typeof(T).FullName);
        }

        public static SimpleQueue<T> GetQueue(string name, IQueueStorage queueStorage)
        {
            return new SimpleQueue<T>(name, queueStorage);
        }

        public QueueMessage<T> GetMessage()
        {
            return _queueStorage.GetMessage<T>();
        }

        public void PushMessage(T testMessage)
        {
            _queueStorage.PushMessage<T>(new QueueMessage<T>(testMessage));
        }

        public void DeleteMessage(Guid messageId)
        {
            _queueStorage.DeleteMessage(messageId);
        }

        public void ClearQueue()
        {
            _queueStorage.ClearQueue();
        }
    }
}