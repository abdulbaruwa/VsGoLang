﻿using System;
using System.Data;
using System.IO;
using System.Reflection;
using System.Data.SqlServerCe;
using Pelican.Common.Serialization;

namespace Pelican.SimpleQueue
{
    public class QueueStorage : IQueueStorage
    {
        private string _queueFilesFolder;

        private static readonly object _lock = new object();

        private string _connection;

        private string _name;

        private string _sdfPath;

        private bool _userDatabaseExists;

        private int _timeout = 30;

        #region IQueueStorage Members

        public void CreateIfRequired(string name, string queueType)
        {
            _name = name;
            _queueFilesFolder = DeriveDataFilePath();
            CreateDataDirectoryIfNeeded(_queueFilesFolder);
            _connection = string.Format(@"data source={0}\{1}.sdf", _queueFilesFolder, name);
            if (AttemptConnection()) return;
            CreateQueueDatabaseAndSchemaIfNeeded();
        }

        private string DeriveDataFilePath()
        {
            return Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "QueueFile");
        }

        private void CreateDataDirectoryIfNeeded(string queueFilesFolder)
        {
            if( ! Directory.Exists(queueFilesFolder))
            {
                Directory.CreateDirectory(queueFilesFolder);
            }
        }

        public void PushMessage<T>(QueueMessage<T> message)
        {
            var queueType = typeof (T).FullName;
            string sql = @"INSERT INTO [Queue] (Message, QueueType, Added, Schedule, Interval) VALUES(@Message, @QueueType, @Added, @Schedule, @Interval)";
            string deserialized = JSONSerializer.Serialize(message.PayLoad);

            using (var conn = new SqlCeConnection(_connection))
            {
                conn.Open();

                using (var cmd = new SqlCeCommand(sql))
                {
                    cmd.Connection = conn;
                    cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 4000).Value = deserialized;
                    cmd.Parameters.Add("@QueueType", SqlDbType.NVarChar, 100).Value = queueType;
                    cmd.Parameters.Add("@Added", SqlDbType.DateTime, 255).Value = DateTime.Now;

                    if (message.Schedule != null)
                        cmd.Parameters.Add("@Schedule", SqlDbType.DateTime, 255).Value = message.Schedule;
                    else
                        cmd.Parameters.Add("@Schedule", SqlDbType.DateTime, 255).Value = DBNull.Value;

                    if (message.Interval != null)
                        cmd.Parameters.Add("@Interval", SqlDbType.Decimal, 15).Value = message.Interval;
                    else
                        cmd.Parameters.Add("@Interval", SqlDbType.Decimal, 15).Value = DBNull.Value;

                    
                    cmd.ExecuteNonQuery(); //Exception for now should bubble up.
                }
            }
        }

        public QueueMessage<T> GetMessage<T>()
        {
            QueueMessage<T> message = null;
            string sql = @"SELECT TOP(1) MessageID, Added, Retrieved, Message, Schedule, Interval
                           FROM [Queue] 
                           WHERE (Schedule IS NULL OR Schedule < GETDATE())
                           AND (Retrieved IS NULL OR Retrieved < @TimeoutDateTime)
                           AND (QueueType =  @queueType)
                           ORDER BY Added";
            string sqlUpdate = @"UPDATE [Queue] SET Retrieved = GETDATE() WHERE MessageID = @id";

            using (var conn = new SqlCeConnection(_connection))
            {
                conn.Open();
                var transaction = conn.BeginTransaction();

                try
                {
                    using (var cmd = new SqlCeCommand(sql, conn, transaction))
                    {
                        cmd.Parameters.Add("@TimeoutDateTime", SqlDbType.DateTime).Value = DateTime.Now.AddSeconds(_timeout * -1);
                        cmd.Parameters.Add("@queueType", SqlDbType.NVarChar).Value = typeof (T).FullName;
                        using (var reader = cmd.ExecuteReader(CommandBehavior.SingleRow))
                        {
                            if (reader.Read())
                            {
                                var payload = JSONSerializer.DeserializeFromJson<T>(reader.GetString(3));
                                message = new QueueMessage<T>(payload)
                                {
                                    MessageId = reader.GetGuid(0),
                                    Added = reader.GetDateTime(1),
                                    Retrieved = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2),
                                    PayLoad = payload,
                                    Schedule = reader.IsDBNull(4) ? (DateTime?)null : reader.GetDateTime(4),
                                    Interval = reader.IsDBNull(5) ? (decimal?)null : reader.GetDecimal(5)

                                };
                            }
                        }
                    }

                    if (message != null)
                    {
                        using (var cmd = new SqlCeCommand(sqlUpdate, conn, transaction))
                        {
                            cmd.Parameters.Add("@id", SqlDbType.UniqueIdentifier).Value = message.MessageId;

                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    // Error getting message - rollback
                    try
                    {
                        transaction.Rollback();
                    }
                    catch (Exception ex)
                    {
                        throw new PelicanSimpleQueueException("Error rolling back Simple Queue Transaction");
                    }
                }
            }

            return message;
        }

        public void ClearQueue()
        {
            const string sql = "DELETE FROM Queue";
            using (var conn = new SqlCeConnection(_connection))
            {
                conn.Open();
                using (var cmd = new SqlCeCommand(sql, conn))
                {
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlCeException e)
                    {
                        throw new PelicanSimpleQueueException(e.GetBaseException().Message);
                    }
                }
            }
        }

        public void DeleteMessage(Guid messageId)
        {
            const string sql = @"DELETE FROM [Queue] WHERE MessageID = @id";
            using (var conn = new SqlCeConnection(_connection))
            {
                conn.Open();
                using (var cmd = new SqlCeCommand(sql, conn))
                {
                    cmd.Parameters.Add("@id", SqlDbType.UniqueIdentifier).Value = messageId;
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlCeException e)
                    {
                        throw new PelicanSimpleQueueException(e.GetBaseException().Message);
                    }
                }
            }
        }

        public bool QueueDatabaseExists
        {
            get { return _userDatabaseExists; }
        }

        public void DeleteDatabase()
        {
            string sdfPath = string.Empty;

            //get path
            using (var testConn = new SqlCeConnection(_connection))
            {
                sdfPath = testConn.Database;
            }

            //todo close db connections?
            if (File.Exists(sdfPath))
            {
                File.Delete(sdfPath);
            }
        }

        #endregion

        private void CreateQueueDatabaseAndSchemaIfNeeded()
        {
            try
            {
                //thread safety first
                lock (_lock)
                {
                    //create database
                    using (var engine = new SqlCeEngine(_connection))
                    {
                        engine.CreateDatabase();
                    }

                    string createScript =
                        @"CREATE TABLE [Queue] (
                                                  [MessageID] uniqueidentifier NOT NULL default NEWID() PRIMARY KEY
                                                , [Message] nvarchar(4000) NOT NULL
                                                , [QueueType] nvarchar(100) NOT NULL
                                                , [Added] datetime NOT NULL
                                                , [Retrieved] datetime NULL
                                                , [Schedule] datetime NULL
                                                , [Interval] decimal(15,3) NULL
                                                );";

                    using (var conn = new SqlCeConnection(_connection))
                    {
                        conn.Open();
                        using (var cmd = new SqlCeCommand())
                        {
                            cmd.Connection = conn;
                            cmd.CommandText = createScript;
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (DirectoryNotFoundException e)
            {
                //Directory possibly deleted during processing
                _userDatabaseExists = false;
                throw new PelicanSimpleQueueException("Target Database Directory not found");
            }
            catch (FileNotFoundException e)
            {
                _userDatabaseExists = false;
                //File Deleted during processing
                throw new PelicanSimpleQueueException("Targe sdf file not found");
            }
            _userDatabaseExists = true;
        }

        public QueueMessage<T> GetMessageWithId<T>(Guid messageId)
        {
            QueueMessage<T> message = null;
            const string sql = @"SELECT TOP(1) MessageID, Added, Retrieved, Message, Schedule, Interval
                           FROM [Queue] 
                           WHERE MessageID = @id";

            const string sqlUpdate = @"UPDATE [Queue] SET Retrieved = GETDATE() WHERE MessageID = @id";

            using (var conn = new SqlCeConnection(_connection))
            {
                conn.Open();
                var transaction = conn.BeginTransaction();

                try
                {
                    using (var cmd = new SqlCeCommand(sql, conn, transaction))
                    {
                        cmd.Parameters.Add("@id", SqlDbType.UniqueIdentifier).Value = messageId;

                        message = ExecuteCommand<T>(cmd);
                    }

                    if (message != null)
                    {
                        using (var cmd = new SqlCeCommand(sqlUpdate, conn, transaction))
                        {
                            cmd.Parameters.Add("@id", SqlDbType.UniqueIdentifier).Value = message.MessageId;

                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch
                {
                    // Error getting message - rollback
                    try
                    {
                        transaction.Rollback();
                    }
                    catch (Exception ex)
                    {
                        throw new PelicanSimpleQueueException("Error rolling back Simple Queue Transaction");
                    }
                }
            }

            return message;
        }

        private QueueMessage<T> ExecuteCommand<T>(SqlCeCommand cmd)
        {
            QueueMessage<T> message = null;
            using (var reader = cmd.ExecuteReader(CommandBehavior.SingleRow))
            {
                if (reader.Read())
                {
                    var payload = JSONSerializer.DeserializeFromJson<T>(reader.GetString(3));
                    message = new QueueMessage<T>(payload)
                                  {
                                      MessageId = reader.GetGuid(0),
                                      Added = reader.GetDateTime(1),
                                      Retrieved = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2),
                                      PayLoad = payload,
                                      Schedule = reader.IsDBNull(4) ? (DateTime?)null : reader.GetDateTime(4),
                                      Interval = reader.IsDBNull(5) ? (decimal?)null : reader.GetDecimal(5)

                                  };
                }
            }
            return message;
        }

        private bool AttemptConnection()
        {
            bool result = false;
            using (var testConn = new SqlCeConnection(_connection))
            {
                _sdfPath = testConn.Database;

                try
                {
                    testConn.Open();
                    result = true;
                }
                catch (SqlCeException)
                {
                }
            }
            return result;
        }
    }
}