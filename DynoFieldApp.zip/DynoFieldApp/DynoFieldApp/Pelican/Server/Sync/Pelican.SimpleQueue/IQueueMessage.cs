﻿using System;

namespace Pelican.SimpleQueue
{
    public interface IQueueMessage
    {
    }

    public interface IQueueMessage<T> : IQueueMessage
    {
        Guid MessageId { get; set; }

        T Payload { get; set; }
    }
}
