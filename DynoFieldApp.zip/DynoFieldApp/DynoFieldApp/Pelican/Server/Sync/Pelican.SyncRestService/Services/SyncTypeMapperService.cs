﻿using System;
using Pelican.Model;

namespace Pelican.SyncRestService.Services
{
    /// <summary>
    /// a service that maps the string representation name of a downloadable 'type' to the
    /// concrete type in order to call the DownSyncQueue
    /// </summary>
    public class SyncTypeMapperService : ISyncTypeMapperService
    {
        public Type MapNameToType(string typeName)
        {
            if (typeName.Trim().ToLower() == "job")
            {
                return typeof (Job);
            }

            return null;
        }
    }
}