﻿using System;

namespace Pelican.SyncRestService.Services
{
    /// <summary>
    /// interface to a service that maps the string representation name of a downloadable 'type' to the
    /// concrete type in order to call the DownSyncQueue
    /// </summary>
    public interface ISyncTypeMapperService
    {
        Type MapNameToType(string typeName);
    }
}
