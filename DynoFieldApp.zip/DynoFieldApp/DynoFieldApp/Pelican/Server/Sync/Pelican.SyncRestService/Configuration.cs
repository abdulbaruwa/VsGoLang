﻿using OpenRasta.Configuration;
using OpenRasta.DI;
using OpenRasta.Security;
using OpenRasta.Web.UriDecorators;
using Pelican.SimpleQueue;
using Pelican.SyncApi;
using Pelican.SyncRestService.Domain;
using Pelican.SyncRestService.Handlers;
using Pelican.SyncRestService.Security;
using Pelican.SyncRestService.Services;

namespace Pelican.SyncRestService
{
    public class Configuration : IConfigurationSource
    {
        public void Configure()
        {
            using (OpenRastaConfiguration.Manual)
            {
                ResourceSpace.Uses.CustomDependency<IUserCredentials, UserCredentials>(DependencyLifetime.Singleton);

                //Service to handle the Down Sync Queue
                ResourceSpace.Uses.CustomDependency<IDownSyncQueue, DownSyncQueue>(DependencyLifetime.Singleton);

                //Service to handle the Down Sync Queue
                ResourceSpace.Uses.CustomDependency<ISyncTypeMapperService, SyncTypeMapperService>(DependencyLifetime.Singleton);

                ResourceSpace.Uses.UriDecorator<ContentTypeExtensionUriDecorator>();

                // registering an instance of IAuthenticationProvider causes the digest authentication to be invoked.
                // it does a check internally whthere there is on in the DI resolver.
                ResourceSpace.Uses.CustomDependency<IAuthenticationProvider, AccountDigestAuthenticationProvider>(DependencyLifetime.Singleton);


                ResourceSpace.Has.ResourcesOfType<IQueueMessage>()
                   .AtUri("/messages/{messagetype}/{messageid}")
                   .And.AtUri("/messages/{messagetype}/next")
                   .HandledBy<MessageQueuesHandler>()
                   .AsJsonDataContract()
                   .And
                   .AsXmlDataContract();
            }
        }
    }
}
