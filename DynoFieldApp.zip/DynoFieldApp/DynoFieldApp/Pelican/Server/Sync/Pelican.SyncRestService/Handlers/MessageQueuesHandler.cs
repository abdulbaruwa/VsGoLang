﻿using System;
using OpenRasta.Security;
using OpenRasta.Web;
using Pelican.SimpleQueue;
using Pelican.SyncApi;
using Pelican.SyncRestService.Services;

namespace Pelican.SyncRestService.Handlers
{
    [RequiresAuthentication]
    public class MessageQueuesHandler
    {
        // will be injected by the IoC built in to openrasta
        public ICommunicationContext Context { get; set; }
        public IDownSyncQueue DownSyncQueue { get; set; }
        public ISyncTypeMapperService SyncTypeMapperService { get; set; }

        
        /// <summary>
        /// Rest service to Get Next message of the requested type
        /// </summary>
        /// <param name="messageType">A string defining the type of message, Job, News etc.</param>
        /// <returns></returns>
        public IQueueMessage Get(string messageType)
        {
            IQueueMessage queueMessage;

            Type TMessage = SyncTypeMapperService.MapNameToType(messageType);
             
            try
            {
                queueMessage = DownSyncQueue.GetNextMessage(Context.User.Identity.Name, TMessage);

//                MethodInfo method = typeof(DownSyncQueue).GetMethod("GetNextMessage"); 
//                MethodInfo generic = method.MakeGenericMethod(TMessageType);
//                generic.Invoke(DownSyncQueue, new object[] { Context.User.Identity.Name }); 
            }
            catch (Exception)
            {
                //log message
                throw;
            }

            return queueMessage;
        }

        /// <summary>
        /// Rest service to Delete a specific message of the requested type from the queue
        /// </summary>
        /// <param name="messageType"></param>
        /// <param name="messageId"></param>
        public void Delete(string messageType, string messageId)
        {
            try
            {
                DownSyncQueue.DeleteMessage(Guid.Parse(messageId), Context.User.Identity.Name);
            }
            catch (Exception)
            {
                //log message
                throw;
            }
        }
    }
}