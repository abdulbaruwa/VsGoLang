﻿using OpenRasta.Security;
using Pelican.SyncRestService.Domain;

namespace Pelican.SyncRestService.Security
{
    public class AccountDigestAuthenticationProvider : IAuthenticationProvider
    {
        private readonly IUserCredentials _users;

        public AccountDigestAuthenticationProvider(IUserCredentials users)
        {
            _users = users;
        }

        public Credentials GetByUsername(string username)
        {
            return _users.GetCredentialsFor(username);
        }
    }
}