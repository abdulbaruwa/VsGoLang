﻿using OpenRasta.Security;

namespace Pelican.SyncRestService.Domain
{
    public interface IUserCredentials
    {
        Credentials GetCredentialsFor(string username);
    }
}