﻿using System.Collections.Generic;
using System.Linq;
using OpenRasta.Security;

namespace Pelican.SyncRestService.Domain
{
    public class UserCredentials : IUserCredentials
    {
        private readonly List<Credentials> _users;

        public UserCredentials()
        {
            _users = new List<Credentials>
                         {
                             new Credentials {Username = "tony", Password = "tony-pass"},
                             new Credentials {Username = "dan", Password = "dan-pass"},
                             new Credentials {Username = "abdul", Password = "abdul-pass"},
                             new Credentials {Username = "ed", Password = "ed-pass"},
                             new Credentials {Username = "jyothi", Password = "jyothi-pass"},
                             new Credentials {Username = "william", Password = "william-pass"}
                         };
        }

        public Credentials GetCredentialsFor(string username)
        {
            return _users.SingleOrDefault(c => c.Username == username);
        }
    }
}