﻿using System;

namespace Pelican.SyncApi
{
    public interface IQueueMessage
    {
    }

    public interface IQueueMessage<T> : IQueueMessage
    {
        Guid MessageId { get; set; }

        T Payload { get; set; }
    }
}
