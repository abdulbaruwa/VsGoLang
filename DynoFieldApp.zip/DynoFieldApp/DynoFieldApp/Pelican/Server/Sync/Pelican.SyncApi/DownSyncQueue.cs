﻿using System;
using Pelican.SimpleQueue;

namespace Pelican.SyncApi
{
    public class DownSyncQueue : IDownSyncQueue
    {
        public IQueueMessage<T> GetNextMessage<T>(string userName, T item) where T : class
        {
            return GetNextMessage<T>(userName);
        }

        public IQueueMessage<T> GetNextMessage<T>(string userName) where T : class
        {
            throw new NotImplementedException();
        }

        public void DeleteMessage(Guid messageId, string userName)
        {
            throw new NotImplementedException();
        }
    }
}
