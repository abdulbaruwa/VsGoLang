﻿using Pelican.SyncApi.Model;

namespace Pelican.SyncApi
{
    public interface IFieldMobileService
    {
        ISyncMessage GetNextMessage<TMessageType>(string userKey);

        void DeleteMessage<TMessageType>(string messageKey, string userKey);
    }
}
