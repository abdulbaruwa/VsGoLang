﻿using System;
using Pelican.SimpleQueue;

namespace Pelican.SyncApi
{
    public interface IDownSyncQueue
    {
        IQueueMessage<T> GetNextMessage<T>(string userName, T item) where T : class;

        IQueueMessage<T> GetNextMessage<T>(string userName) where T : class;

        void DeleteMessage(Guid messageId, string userName);
    }
}
