﻿using System;

namespace Pelican.SyncApi
{
    public class QueueMessage<T> : IQueueMessage<T>
    {
        public Guid MessageId { get; set; }

        public T Payload { get; set; }
    }
}
