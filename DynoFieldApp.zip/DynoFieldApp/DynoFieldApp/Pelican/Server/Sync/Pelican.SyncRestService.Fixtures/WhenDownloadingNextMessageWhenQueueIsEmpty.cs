using NUnit.Framework;
using Pelican.Model;
using Pelican.TestExtensions;
using Rhino.Mocks;

namespace Pelican.SyncRestService.Fixtures
{
    [TestFixture]
    public class WhenDownloadingNextMessageWhenQueueIsEmpty : SyncRestfulServiceFixtureBase
    {
        private object _returnedObject;

        protected override void CreateMessagesForQueue()
        {
            DownSyncQueue.Stub(x => x.GetNextMessage(JobMessage, typeof(Job))).Return(null).IgnoreArguments();
        }
 
        protected override void Because()
        {
            _returnedObject = MessageQueuesHandler.Get(JobMessage);
        }

        [Test]
        public void MessageQueuesHandlerShouldReturnNull()
        {
            _returnedObject.ShouldBeNull();
        }
    }
}