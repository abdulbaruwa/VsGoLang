using System;
using NUnit.Framework;
using Pelican.Model;
using Rhino.Mocks;

namespace Pelican.SyncRestService.Fixtures
{
    [TestFixture]
    public class WhenDeletingMessageFromQueue : SyncRestfulServiceFixtureBase
    {
        protected override void Because()
        {
            MessageQueuesHandler.Delete(JobMessage, QueueMessage1.MessageId.ToString());
        }

        [Test]
        public void MessageQueuesHandlerDeleteMethodShouldBeCalled()
        {
            DownSyncQueue.AssertWasCalled(x => x.DeleteMessage(Guid.NewGuid(), null), x => x.IgnoreArguments());
        }

        [Test]
        public void MessageQueuesHandlerDeleteMethodShouldBeCalledForTheCorrectMessage()
        {
            DownSyncQueue.AssertWasCalled(x => x.DeleteMessage(QueueMessage1.MessageId, Context.User.Identity.Name));
        }
    }
}