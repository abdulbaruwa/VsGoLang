using System;
using System.Security.Principal;
using OpenRasta.Web;
using Pelican.Model;
using Pelican.SimpleQueue;
using Pelican.SyncApi;
using Pelican.SyncRestService.Handlers;
using Pelican.SyncRestService.Services;
using Pelican.TestExtensions;
using Rhino.Mocks;

namespace Pelican.SyncRestService.Fixtures
{
    public abstract class SyncRestfulServiceFixtureBase : SingleRunBaseContext<MessageQueuesHandler>
    {
        protected MessageQueuesHandler MessageQueuesHandler;
        protected IDownSyncQueue DownSyncQueue;
        protected ICommunicationContext Context;
        protected ISyncTypeMapperService SyncTypeMapperService;
        protected IPrincipal Principal;
        protected IIdentity Identity;
        protected IQueueMessage<Type> QueueMessage1;
        protected string JobMessage = "job";

        protected override MessageQueuesHandler SetupContext()
        {
            //create a mock DownSyncQueue to simulate the return of messages from a queue
            DownSyncQueue = MockRepository.GenerateMock<IDownSyncQueue>();

            //Create the message to return from queue
            CreateMessagesForQueue();
            
            //create a mock CommunicationContext to simulate a valid user identity
            CreateUserContext();

            //create service to map the messagetype as string to Type
            CreateSyncTypeMapperService();

            //create the Rest service handler
            MessageQueuesHandler = new MessageQueuesHandler { DownSyncQueue = DownSyncQueue, Context = Context, SyncTypeMapperService = SyncTypeMapperService};

            return MessageQueuesHandler;
        }
        
        protected virtual void CreateMessagesForQueue()
        {
            QueueMessage1 = MockRepository.GenerateMock<IQueueMessage<Type>>();
            QueueMessage1.Stub(x => x.MessageId).Return(Guid.NewGuid());

            DownSyncQueue.Stub(x => x.GetNextMessage(JobMessage, typeof(Job))).Return(QueueMessage1).IgnoreArguments();
        }

        protected virtual void CreateUserContext()
        {
            Identity = MockRepository.GenerateMock<IIdentity>();
            Identity.Stub(x => x.Name).Return("tony");
            Identity.Stub(x => x.IsAuthenticated).Return(true);

            Principal = MockRepository.GenerateMock<IPrincipal>();
            Principal.Stub(x => x.Identity).Return(Identity);

            Context = MockRepository.GenerateMock<ICommunicationContext>();
            Context.Stub(x => x.User).Return(Principal);
        }

        protected virtual void CreateSyncTypeMapperService()
        {
            SyncTypeMapperService = MockRepository.GenerateMock<ISyncTypeMapperService>();
            SyncTypeMapperService.Stub(x => x.MapNameToType("job")).Return(typeof(Job));
        }
    }
}