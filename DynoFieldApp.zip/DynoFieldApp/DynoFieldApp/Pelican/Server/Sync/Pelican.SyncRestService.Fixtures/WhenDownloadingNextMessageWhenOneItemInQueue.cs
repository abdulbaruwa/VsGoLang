using NUnit.Framework;
using Pelican.TestExtensions;

namespace Pelican.SyncRestService.Fixtures
{
    [TestFixture]
    public class WhenDownloadingNextMessageWhenOneItemInQueue : SyncRestfulServiceFixtureBase
    {
        private object _returnedObject;

        protected override void Because()
        {
            _returnedObject = MessageQueuesHandler.Get(JobMessage);
        }

        [Test]
        public void MessageQueuesHandlerShouldReturnAnObject()
        {
            _returnedObject.ShouldNotBeNull();
        }

        [Test]
        public void MessageQueuesHandlerShouldReturnToCorrectMessage()
        {
            _returnedObject.ShouldEqual(QueueMessage1);
        }
    }
}