using Pelican.TestExtensions;
using Rhino.Mocks;

namespace Pelican.SimpleQueue.Fixtures.SimpleQueueFixtures
{
    public abstract class SimpleQueueFixtureBase : BaseContext<SimpleQueue<string>>
    {
        protected IQueueStorage QueueStorage;

        protected override SimpleQueue<string> SetupContext()
        {
            QueueStorage = MockRepository.GenerateMock<IQueueStorage>();
            return SimpleQueue<string>.GetQueue("TestQueue",QueueStorage);
        }
    }
}