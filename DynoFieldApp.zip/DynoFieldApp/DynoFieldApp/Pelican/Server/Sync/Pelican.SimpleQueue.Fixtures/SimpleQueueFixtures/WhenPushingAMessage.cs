using NUnit.Framework;
using Rhino.Mocks;

namespace Pelican.SimpleQueue.Fixtures.SimpleQueueFixtures
{
    [TestFixture]
    public class WhenPushingAMessage : SimpleQueueFixtureBase
    {
        protected override void Because()
        {
            Sut.PushMessage("Test Message");
        }

        [Test]
        public void ShouldCallPushMessageOnQueueStorage()
        {
            QueueStorage.AssertWasCalled(x => x.PushMessage(new QueueMessage<string>("Test Message")),y => y.IgnoreArguments());
        }
    }
}