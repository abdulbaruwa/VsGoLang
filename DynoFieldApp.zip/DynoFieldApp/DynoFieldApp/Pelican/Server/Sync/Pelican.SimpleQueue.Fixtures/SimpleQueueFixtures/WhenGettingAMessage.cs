using System;
using NUnit.Framework;
using Rhino.Mocks;
using Pelican.TestExtensions;

namespace Pelican.SimpleQueue.Fixtures.SimpleQueueFixtures
{
    public class WhenGettingAMessage : SimpleQueueFixtureBase
    {
        private QueueMessage<string> result;
        private QueueMessage<string> output;

        protected override SimpleQueue<string> SetupContext()
        {
            result = new QueueMessage<string>("Test Message");
            var sut = base.SetupContext();
            QueueStorage.Stub(x => x.GetMessage<string>()).Return(result);
            return sut;
        }
        protected override void Because()
        {
            output = Sut.GetMessage();
        }

        [Test]
        public void ShouldCallGetMessageOnQueueStorage()
        {
            QueueStorage.AssertWasCalled(x => x.GetMessage<string>());
        }

        [Test]
        public void ShouldReturnTypeOfQueueMessage()
        {
            Assert.AreEqual(result, output);
        }
    }
}