using System;
using NUnit.Framework;
using Rhino.Mocks;

namespace Pelican.SimpleQueue.Fixtures.SimpleQueueFixtures
{
    public class WhenClearingAQueue : SimpleQueueFixtureBase
    {
        protected override void Because()
        {
            Sut.ClearQueue();
        }


        [Test]
        public void ShouldCallClearMessage()
        {
            QueueStorage.AssertWasCalled(x => x.ClearQueue());
        }
    }
}