using Rhino.Mocks;
using NUnit.Framework;
using Pelican.TestExtensions;

namespace Pelican.SimpleQueue.Fixtures.SimpleQueueFixtures
{
    [TestFixture]
    public class WhenGetingAQueueInstance :  BaseContext
    {
        private IQueueStorage queueStorage;
        private SimpleQueue<string> result;

        protected override void SetupContext()
        {
            base.SetupContext();
            queueStorage = MockRepository.GenerateMock<IQueueStorage>();
        }
        protected override void Because()
        {
            result = SimpleQueue<string>.GetQueue("TestQueue", queueStorage);
        }

        [Test]
        public void ShouldReturnAnInstanceOfSimpleQueue()
        {
            result.ShouldBeOfType( typeof(SimpleQueue<string>));
        }

        [Test]
        public void ShouldCallCreateIfRequiredOnQueueStorage()
        {
            queueStorage.AssertWasCalled(x => x.CreateIfRequired("TestQueue", "System.String"));
        }
    }
}