using System;
using NUnit.Framework;
using Rhino.Mocks;

namespace Pelican.SimpleQueue.Fixtures.SimpleQueueFixtures
{
    public class WhenDeletingAMessage : SimpleQueueFixtureBase
    {
        private Guid messageId;

        protected override SimpleQueue<string> SetupContext()
        {
            var sut =  base.SetupContext();
            messageId = Guid.NewGuid();
            return sut;
        }

        protected override void Because()
        {
            Sut.DeleteMessage(messageId);
        }

        [Test]
        public void ShouldCallDeleteMessageOnStorageQueue()
        {
            QueueStorage.AssertWasCalled(x => x.DeleteMessage(messageId));
        }
    }
}