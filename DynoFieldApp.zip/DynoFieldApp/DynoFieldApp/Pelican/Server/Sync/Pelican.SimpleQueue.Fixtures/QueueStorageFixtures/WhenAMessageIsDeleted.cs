﻿using NUnit.Framework;
using Pelican.TestExtensions;

namespace Pelican.SimpleQueue.Fixtures.QueueStorageFixtures
{
    [TestFixture]
    public class WhenAMessageIsDeleted : QueryStorageFixtureBase
    {
        private QueueMessage<string> _testMessage;
        private QueueMessage<string> _outTestMessage;

        protected override IQueueStorage SetupContext()
        {
            _testMessage = new QueueMessage<string>("Test Message");
            var sut = base.SetupContext();
            sut.CreateIfRequired(Username, QueueType);
            sut.PushMessage(_testMessage);
            _outTestMessage = sut.GetMessage<string>();
            return sut;
        }

        protected override void Because()
        {
            Sut.DeleteMessage(_outTestMessage.MessageId);   
        }

        [Test]
        public void ShouldRemoveMessagePermanentlyFromTheQueue()
        {
            Sut.GetMessageWithId<string>(_outTestMessage.MessageId).ShouldBeNull();
        }
    }
}