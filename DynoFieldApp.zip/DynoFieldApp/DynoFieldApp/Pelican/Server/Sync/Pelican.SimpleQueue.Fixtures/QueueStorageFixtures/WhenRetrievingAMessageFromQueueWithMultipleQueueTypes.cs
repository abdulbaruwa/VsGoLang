﻿using System;
using NUnit.Framework;
using Pelican.TestExtensions;

namespace Pelican.SimpleQueue.Fixtures.QueueStorageFixtures
{
    [TestFixture]
    public class WhenRetrievingAMessageFromQueueWithMultipleQueueTypes : QueryStorageFixtureBase
    {
        private object _outTestMessage;

        protected override IQueueStorage SetupContext()
        {
            var sut = base.SetupContext();
            sut.CreateIfRequired(Username, QueueType);
            sut.PushMessage(new QueueMessage<string>("Test Message"));
            sut.PushMessage(new QueueMessage<double>(12345.60));
            sut.PushMessage(new QueueMessage<Guid>(Guid.NewGuid()));
            return sut;
        }

        protected override void Because()
        {
            _outTestMessage = Sut.GetMessage<Double>();
        }

        [Test]
        public void ShouldReturnAValidQueueMessage()
        {
            _outTestMessage.ShouldNotBeNull();
        }

        [Test]
        public void ShouldInsertMessageWithMessageIdSet()
        {
            _outTestMessage.ShouldBeOfType(typeof(QueueMessage<double>));
            var nextMessage = Sut.GetMessage<Guid>();
            nextMessage.ShouldBeOfType(typeof(QueueMessage<Guid>));
        }

    }
}