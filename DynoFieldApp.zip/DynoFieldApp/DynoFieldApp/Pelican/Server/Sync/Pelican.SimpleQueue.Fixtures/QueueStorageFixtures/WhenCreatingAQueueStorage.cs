using NUnit.Framework;
using Pelican.TestExtensions;

namespace Pelican.SimpleQueue.Fixtures.QueueStorageFixtures
{
    [TestFixture]
    public class WhenCreatingAQueueStorage : QueryStorageFixtureBase
    {

        protected override void Because()
        {
            Sut.CreateIfRequired(Username, QueueType);
        }

        [Test]
        public void ShouldCreateTheQueueStore()
        {
            Sut.QueueDatabaseExists.ShouldBeTrue();
        }

    }
}