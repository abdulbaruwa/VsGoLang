using NUnit.Framework;
using Pelican.TestExtensions;

namespace Pelican.SimpleQueue.Fixtures.QueueStorageFixtures
{
    public abstract class QueryStorageFixtureBase : BaseContext<IQueueStorage>
    {
        protected string QueueType;
        protected string Username;

        protected override IQueueStorage SetupContext()
        {
            Username = "TestUser";
            QueueType = "CreateJob";
            return new QueueStorage();
        }

        [TestFixtureTearDown]
        protected void TestComplete()
        {
            Sut.DeleteDatabase();
        }

    }
}