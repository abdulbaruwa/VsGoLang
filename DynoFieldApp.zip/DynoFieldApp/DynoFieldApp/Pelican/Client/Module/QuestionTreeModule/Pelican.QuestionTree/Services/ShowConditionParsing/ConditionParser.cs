﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Services.Specifications;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public class ConditionParser : IConditionParser
    {
        private readonly IConditionLexer _lexer;
        private IList<Filter> _filters;
        private IList<QuestionViewModel> _questions;        

        public ConditionParser(IConditionLexer lexer)
        {
            _lexer = lexer;
        }
        
        public ISpecification Parse(string condition, IList<QuestionViewModel> questions, string questionnaireReference, IQuestionnaireViewModel questionnaireViewModel)
        {
            _questions = questions;
            _lexer.Build(new StringReader(condition ?? string.Empty));
            _filters = _filterDefinitionRetriever.GetFilterDefinitions(questionnaireReference);

            Token token = _lexer.NextToken();
            if (token.Kind == Tokens.Eof) return new NullSpecification();

            ISpecification returnSpecification;
            ExprGroup(out returnSpecification, questionnaireViewModel);
            return returnSpecification;
        }

        private void ExprGroup(out ISpecification returnSpecification, IQuestionTreeViewModel questionTreeViewModel)
        {
            Expr(out returnSpecification, questionnaireViewModel);
            OrExpr(ref returnSpecification, questionnaireViewModel);
        }

        private void Expr(out ISpecification returnSpecification, IQuestionnaireViewModel questionnaireViewModel)
        {
            Token token = _lexer.CurrentToken;

            if (token.Kind == Tokens.Not)
            {
                NotExpr(out returnSpecification, questionnaireViewModel);
            }
            else if (token.Kind == Tokens.OpenParenthesis)
            {
                _lexer.NextToken();
                ExprGroup(out returnSpecification, questionnaireViewModel);
                _lexer.NextToken();
            }
            else
            {
                MatchExpr(out returnSpecification, questionnaireViewModel);
            }
        }

        private void NotExpr(out ISpecification returnSpecification, IQuestionnaireViewModel questionnaireViewModel)
        {
            Token token = _lexer.NextToken();
            ISpecification expr;
            Expr(out expr, questionnaireViewModel);
            returnSpecification = new NotSpecification(expr);
        }

        private void MatchExpr(out ISpecification returnSpecification, IQuestionnaireViewModel questionnaireViewModel)
        {
            Token token = _lexer.CurrentToken;
            QuestionFilterDefinition filter = _filters.First(x => x.Code.ToLower() == token.Value.ToLower());

            if (filter.Type == FilterType.Question)
            {
                if (filter.LinkedQuestionnaireCode != filter.QuestionnaireCode)
                {
                    returnSpecification = new IsExternalQuestionMatchSpecification(filter, questionnaireViewModel.Visit);
                }
                else
                {
                    QuestionViewModel question =
                    _questions.First(x => x.Code.ToLower() == filter.LinkedQuestionCode.ToLower());

                    returnSpecification = new IsQuestionMatchSpecification(question, filter.MatchValueFrom, filter.MatchValueTo);
                }                
            }
            else
            {
                returnSpecification = _fixedTableMatchSpecificationFactory.Create(filter.TableValueTable,
                                                                                  filter.TableValueColumn,
                                                                                  filter.MatchValueFrom,
                                                                                  questionnaireViewModel);
            }

            _lexer.NextToken();
        }

        private void AndExpr(ref ISpecification returnSpecification, IQuestionnaireViewModel questionnaireViewModel)
        {
            while (_lexer.CurrentToken.Kind == Tokens.And)
            {
                _lexer.NextToken();
                ISpecification spec;
                Expr(out spec, questionnaireViewModel);
                returnSpecification = returnSpecification.And(spec);
            }
        }

        private void OrExpr(ref ISpecification returnSpecification, IQuestionnaireViewModel questionnaireViewModel)
        {
            AndExpr(ref returnSpecification, questionnaireViewModel);

            while (_lexer.CurrentToken.Kind == Tokens.Or)
            {
                _lexer.NextToken();
                ISpecification spec;
                Expr(out spec, questionnaireViewModel);
                AndExpr(ref spec, questionnaireViewModel);
                returnSpecification = returnSpecification.Or(spec);
            }
        }

    }
}