﻿using System.Collections.Generic;
using System.Linq;
using Pelican.Common.MVVM;

namespace Pelican.QuestionTree.ViewModels
{
    public class GroupViewModel : ValidatingViewModelBase<GroupViewModel>
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public List<QuestionViewModel> QuestionViewModels { get; set; }

        /// <summary>
        /// Determines whether the group tab should be enabled
        /// </summary>
        public override bool IsEnabled
        {
            get
            {
                return base.IsEnabled && QuestionViewModels != null && QuestionViewModels.Any(x => x.Show);
            }
        }


        #region Raise Notifications

        /// <summary>
        /// Raise Notifications When Question of group Show Property Changed
        /// </summary>
        public void RaiseQuestionShowNotificationChanged()
        {
            NotifyOfPropertyChange(() => IsEnabled);
            NotifyOfPropertyChange(() => IsValid);
        }
        #endregion

       
    }
}