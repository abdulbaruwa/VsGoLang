﻿namespace Pelican.QuestionTree.Services.Specifications
{
    public class AndSpecification : AbstractSpecification
    {
        private readonly ISpecification _baseSpecification;
        private readonly ISpecification _otherSpecification;

        public AndSpecification(ISpecification baseSpecification, ISpecification otherSpecification)
        {
            _otherSpecification = otherSpecification;
            _baseSpecification = baseSpecification;
        }

        public override bool IsSatisfied()
        {
            return _baseSpecification.IsSatisfied() && _otherSpecification.IsSatisfied();
        }
    }
}
