﻿using System.Collections.Generic;
using Pelican.Common.MVVM;

namespace Pelican.QuestionTree.ViewModels
{
    public class QuestionTreeViewModel : HierarchicalViewModelBase<QuestionTreeViewModel>, IQuestionTreeViewModel
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public List<GroupViewModel> GroupViewModels { get; set; }
    }
}