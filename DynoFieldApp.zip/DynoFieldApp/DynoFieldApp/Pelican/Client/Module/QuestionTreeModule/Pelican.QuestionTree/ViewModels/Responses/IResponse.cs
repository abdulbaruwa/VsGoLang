﻿namespace Pelican.QuestionTree.ViewModels.Responses
{
    public interface IResponse
    {
        string MinValue { get; set; }
        string MaxValue { get; set; }
    }
}