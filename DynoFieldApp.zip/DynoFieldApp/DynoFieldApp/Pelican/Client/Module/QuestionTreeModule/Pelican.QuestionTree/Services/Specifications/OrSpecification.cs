﻿namespace Pelican.QuestionTree.Services.Specifications
{
    public class OrSpecification : AbstractSpecification
    {
        private readonly ISpecification _baseSpecification;
        private readonly ISpecification _otherSpecification;

        public OrSpecification(ISpecification baseSpecification, ISpecification otherSpecification)
        {
            _otherSpecification = otherSpecification;
            _baseSpecification = baseSpecification;
        }

        public override bool IsSatisfied()
        {
            return _baseSpecification.IsSatisfied() || _otherSpecification.IsSatisfied();
        }
    }
}
