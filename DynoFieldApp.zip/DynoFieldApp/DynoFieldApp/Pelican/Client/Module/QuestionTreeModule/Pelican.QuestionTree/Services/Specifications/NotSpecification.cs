﻿namespace Pelican.QuestionTree.Services.Specifications
{
    public class NotSpecification : AbstractSpecification
    {
        private readonly ISpecification _baseSpecification;

        public NotSpecification(ISpecification baseSpecification)
        {
            _baseSpecification = baseSpecification;
        }

        public override bool IsSatisfied()
        {
            if (!_baseSpecification.HasValue) return true;

            return !_baseSpecification.IsSatisfied();
        }
    }
}
