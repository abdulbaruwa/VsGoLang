﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pelican.QuestionTree.Model;

namespace Pelican.QuestionTree.ViewModels.Responses
{
    public class DropdownResponse : LookupResponseBase
    {
        
    }
}
