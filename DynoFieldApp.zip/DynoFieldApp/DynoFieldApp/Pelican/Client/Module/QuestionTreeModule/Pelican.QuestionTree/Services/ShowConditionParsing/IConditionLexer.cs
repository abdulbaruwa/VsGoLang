﻿using System.IO;

namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public interface IConditionLexer
    {
        void Build(TextReader textReader);

        Token CurrentToken { get; }

        Token NextToken();
    }
}
