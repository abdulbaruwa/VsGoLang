﻿namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public static class Tokens
    {
        public const int Eof = 0;
        public const int FilterCondition = 1;
        public const int OpenParenthesis = 2;
        public const int CloseParenthesis = 3;

        // Keywords
        public const int And = 50;
        public const int Or = 51;
        public const int Not = 52;
    }
}
