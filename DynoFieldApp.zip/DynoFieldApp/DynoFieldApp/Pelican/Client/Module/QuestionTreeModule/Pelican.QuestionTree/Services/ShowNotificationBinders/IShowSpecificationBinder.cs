﻿using System.Collections.Generic;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.ShowNotificationBinders
{
    public interface IShowSpecificationBinder
    {
        void Bind(Model.Schema.QuestionTree questionTree, IQuestionTreeViewModel questionTreeViewModel);
    }
}
