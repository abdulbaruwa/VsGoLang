﻿using AutoMapper;
using Microsoft.Practices.Unity;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;
using Pelican.QuestionTree.Services;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Configuration
{
    public class AutoMapperConfiguration : IAutoMapperConfiguration
    {

        #region IAutoMapperConfiguration Members

        public void Configure()
        {
            Mapper.CreateMap<Question, QuestionViewModel>()
                .ForMember(x => x.Response, opt => opt.ResolveUsing<ResponseResolver>().ConstructedBy(() => new ResponseResolver(new QuestionTreeConfigurationSettings(), new QuestionTreeSchemaRetriever(new QuestionTreeConfigurationSettings()))));

            Mapper.CreateMap<Model.Schema.QuestionTree, QuestionTreeViewModel>()
                .ForMember(dest => dest.GroupViewModels, opt => opt.ResolveUsing<GroupViewModelsResolver>().ConstructedBy(() => new GroupViewModelsResolver(new QuestionTreeConfigurationSettings())));
        }

        #endregion
    }
}