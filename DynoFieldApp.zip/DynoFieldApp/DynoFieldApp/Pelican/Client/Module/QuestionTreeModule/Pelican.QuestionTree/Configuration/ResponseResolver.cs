﻿using System;
using System.Linq;
using AutoMapper;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;
using Pelican.QuestionTree.Services;
using Pelican.QuestionTree.ViewModels.Responses;

namespace Pelican.QuestionTree.Configuration
{
    public class ResponseResolver : ValueResolver<Question, IResponse>
    {
        private readonly IQuestionTreeConfigurationSettings _questionTreeConfigurationSettings;
        private readonly IQuestionTreeSchemaRetriever _questionTreeSchemaRetriever;

        public ResponseResolver(IQuestionTreeConfigurationSettings questionTreeConfigurationSettings, IQuestionTreeSchemaRetriever questionTreeSchemaRetriever)
        {
            _questionTreeConfigurationSettings = questionTreeConfigurationSettings;
            _questionTreeSchemaRetriever = questionTreeSchemaRetriever;
        }

        protected override IResponse ResolveCore(Question question)
        {
            IResponse resultResponse;
            switch (question.QuestionDataType)
            {
                case QuestionDataType.Boolean:
                    resultResponse = new BooleanResponse();
                    break;
                case QuestionDataType.Lookup:
                    resultResponse = ResolveLookUpResponse(question);
                    break;
                case QuestionDataType.Integer:
                    resultResponse = new IntegerResponse();
                    break;
                case QuestionDataType.Decimal:
                    resultResponse = new DecimalResponse();
                    break;
                case QuestionDataType.Date:
                    resultResponse = new DateResponse();
                    break;
                case QuestionDataType.DateTime:
                    resultResponse = new DateTimeResponse();
                    break;
                case QuestionDataType.Photo:
                    resultResponse = new PhotoResponse();
                    break;
                case QuestionDataType.Drawing:
                    resultResponse = new DrawingResponse();
                    break;
                case QuestionDataType.Signature:
                    resultResponse = new SignatureResponse();
                    break;
                default:
                    resultResponse = new TextResponse();
                    break;
            }

            SetResponseValues(question, resultResponse);
            return resultResponse;
        }

        private static void SetResponseValues(Question question, IResponse response)
        {
            response.MinValue = question.MinValue;
            response.MaxValue = question.MaxValue;
        }

        private IResponse ResolveLookUpResponse(Question question)
        {
            QuestionTreeSchema questionTreeSchema = _questionTreeSchemaRetriever.QuestionTreeSchema;
            var lookupGroup = questionTreeSchema.LookupGroups.FirstOrDefault(x => x.Code == question.GroupCode);
            IResponse resultResponse = (lookupGroup == null || lookupGroup.Lookups == null || lookupGroup.Lookups.Count <= _questionTreeConfigurationSettings.LookupCountforRadioButon) ? (IResponse)new RadiobuttonResponse() : new DropdownResponse();
            ((LookupResponseBase)resultResponse).LookupGroup = lookupGroup;

            return resultResponse;
        }
    }
}