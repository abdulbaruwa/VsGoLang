﻿using System.IO;
using System.Linq;
using Pelican.Common.Serialization;
using Pelican.QuestionTree.Configuration;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;

namespace Pelican.QuestionTree.Services
{
    public class QuestionTreeSchemaRetriever : IQuestionTreeSchemaRetriever
    {
        #region static variables

        private static readonly object keyLock = new object();
        private static QuestionTreeSchema _questionTreeSchema;

        #endregion

        #region IQuestionTreeSchemaRetriever Members

        public QuestionTreeSchema QuestionTreeSchema
        {
            get { return _questionTreeSchema; }
        }
        
        #endregion

        #region Constructor

        public QuestionTreeSchemaRetriever(IQuestionTreeConfigurationSettings questionTreeConfigurationSettings)
        {
            GetQuestionTreeSchema(questionTreeConfigurationSettings);
        }

        #endregion

        #region Private Methods
        private static void GetQuestionTreeSchema(IQuestionTreeConfigurationSettings questionTreeConfigurationSettings)
        {
            lock (keyLock)
            {
                if (_questionTreeSchema == null)
                {
                    string filepath = questionTreeConfigurationSettings.QuestionTreeJsonFilePath;

                    if (!File.Exists(filepath))
                        throw new FileNotFoundException(string.Format("Unable to find the Json file '{0}'", filepath));

                    using (var streamReader = new StreamReader(questionTreeConfigurationSettings.QuestionTreeJsonFilePath))
                    {
                        string jsonString = streamReader.ReadToEnd();
                        _questionTreeSchema = JSONSerializer.Deserialize<QuestionTreeSchema>(jsonString);
                        streamReader.Close();
                    }
                }
            }
        }

      
        #endregion
    }
}