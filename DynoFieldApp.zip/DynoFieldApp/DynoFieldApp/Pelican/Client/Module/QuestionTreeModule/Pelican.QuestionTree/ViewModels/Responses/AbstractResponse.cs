﻿using System;
using Pelican.Common.MVVM;

namespace Pelican.QuestionTree.ViewModels.Responses
{
    public abstract class AbstractResponse : ValidatingViewModelBase<AbstractResponse>, IResponse
    {
        #region IResponse Members
        public string MinValue { get; set; }
        public string MaxValue { get; set; }

        public string Value { get; set; }

        #endregion
    }
}