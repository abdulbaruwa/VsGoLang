﻿using System.Collections.Generic;
using System.Linq;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;
using Pelican.QuestionTree.Services.ShowConditionParsing;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.ShowNotificationBinders
{
    public class ShowSpecificationBinder : IShowSpecificationBinder
    {
        private readonly IConditionParser _conditionParser;

        public ShowSpecificationBinder(IConditionParser conditionParser)
        {
            _conditionParser = conditionParser;
        }

        #region IShowSpecificationBinder Members

        public void Bind(Model.Schema.QuestionTree questionTree, IQuestionTreeViewModel questionTreeViewModel)
        {
            List<QuestionViewModel> questionViewModels = questionTreeViewModel.GroupViewModels.SelectMany(x => x.QuestionViewModels).ToList();
            foreach (Question questionTreeQuestion in questionTree.Questions)
            {
                Question question = questionTreeQuestion;
                QuestionViewModel questionViewModel = questionViewModels.First(x => x.Code == question.Code);
                questionViewModel.ShowSpecification = _conditionParser.Parse(question, questionViewModel);

                //BindResponseLookUpSpecification(questionViewModels, definition, questionViewModel, questionnaireReference, questionTreeViewModel);
            }
        }

        #endregion

        //private void BindResponseLookUpSpecification(IList<QuestionViewModel> questionViewModels,
        //                                            Question definition, QuestionViewModel questionViewModel,
        //                                            string questionnaireReference, IQuestionTreeViewModel questionTreeViewModel)
        //{

        //    if (questionViewModel.Response == null || !(questionViewModel.Response is DropdownResponse) || definition.LookupValues == null) return;

        //    var dropdownResponse = questionViewModel.Response as DropdownResponse;
        //    var questionLookUps = definition.LookupValues.Where(x => !string.IsNullOrEmpty(x.Condition));

        //    foreach (var questionLookUp in questionLookUps)
        //    {
        //        QuestionLookUp up = questionLookUp;
        //        var responseLookUp = dropdownResponse.LookupValues.First(x => x.Value == up.Value && x.Description == up.Description);
        //        responseLookUp.ShowSpecification = _conditionParser.Parse(up.Condition, questionViewModels, questionnaireReference, questionTreeViewModel);
        //    }
        //}
    }
}