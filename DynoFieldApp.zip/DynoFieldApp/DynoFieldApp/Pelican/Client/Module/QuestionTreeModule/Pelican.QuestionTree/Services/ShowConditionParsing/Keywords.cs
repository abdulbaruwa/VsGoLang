﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public static class Keywords
    {
        static readonly string[] KeywordList = {
			"and",
			"or",
			"not"
		};

        static readonly Dictionary<string, int> KeywordMap = new Dictionary<string, int>();

        static Keywords()
        {
            for (int i = 0; i < KeywordList.Length; ++i)
            {
                KeywordMap[KeywordList[i]] = i + Tokens.And;
            }
        }

        public static int GetToken(string keyword)
        {
            if (!KeywordMap.ContainsKey(keyword)) return -1;

            return KeywordMap[keyword];
        }
    }
}
