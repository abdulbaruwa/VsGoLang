﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Configuration
{
    public class GroupViewModelsResolver : ValueResolver<Model.Schema.QuestionTree, IList<GroupViewModel>>
    {

        #region Fields 
        private readonly IQuestionTreeConfigurationSettings _questionTreeConfigurationSettings;
        #endregion

        #region Constuctor
        public GroupViewModelsResolver(IQuestionTreeConfigurationSettings questionTreeConfigurationSettings)
        {
            _questionTreeConfigurationSettings = questionTreeConfigurationSettings;
        }
        #endregion

        /// <summary>
        /// Resolve Group View Model
        /// </summary>
        /// <param name="questionTree"></param>
        /// <returns></returns>
        protected override IList<GroupViewModel> ResolveCore(Model.Schema.QuestionTree questionTree)
        {
            IList<GroupViewModel> groupViewModels = new List<GroupViewModel>();

            AssignUnallocatedQuestionsToDefaultGroup(questionTree);

            ValidateGroup(questionTree);

            foreach (var questionGroup in questionTree.Groups)
            {
                var groupViewModel = new GroupViewModel
                                                    {
                                                        Code = questionGroup.Code,
                                                        Description = questionGroup.Description,
                                                        QuestionViewModels =  new List<QuestionViewModel>()
                                                    };

                var questions = questionTree.Questions.Where(x => x.GroupCode.ToLower() == questionGroup.Code.ToLower());
                foreach (var question in questions)
                {
                  groupViewModel.QuestionViewModels.Add(Mapper.Map<Question, QuestionViewModel>(question));
                }
                groupViewModels.Add(groupViewModel);
            }

            return groupViewModels;
        }
        
        #region Private Methods

        /// <summary>
        /// Assign Unallocated Questions To Default Group (Misc)
        /// </summary>
        /// <param name="questionTree"></param>
        private void AssignUnallocatedQuestionsToDefaultGroup(Model.Schema.QuestionTree questionTree)
        {
            if (!questionTree.Questions.Any(x => string.IsNullOrEmpty(x.GroupCode))) return;
            var questionGroup = new Group()
                                    {
                                        Code = "misc",
                                        Description = _questionTreeConfigurationSettings.DefaultQuestionGroupDescription
                                    };
            questionTree.Groups.Add(questionGroup);
            foreach (var question in questionTree.Questions.Where(x => string.IsNullOrEmpty(x.GroupCode)))
            {
                question.GroupCode = questionGroup.Code;
            }
        }

        /// <summary>
        /// Validate Group
        /// a. InValid Group Allocated To Question
        /// b. QuestionTree has group but not allocated to any Question
        /// </summary>
        /// <param name="questionTree"></param>
        private static void ValidateGroup(Model.Schema.QuestionTree questionTree)
        {
            ValidateInValidGroupAllocatedToQuestion(questionTree);
            
            ValidateGroupHasNoQuestions(questionTree);
        }

        /// <summary>
        /// InValid Group Allocated To Question
        /// Question Group Code is not in QuestionTree Groups
        /// </summary>
        /// <param name="questionTree"></param>
        private static void ValidateInValidGroupAllocatedToQuestion(Model.Schema.QuestionTree questionTree)
        {
            foreach (var question in questionTree.Questions.Where(question => !questionTree.Groups.Any(x => x.Code.ToLower() == question.GroupCode.ToLower())))
            {
                throw new Exception("InValid Group Allocated To Question. question:"+ question.Code);
            }
        }

        /// <summary>
        /// QuestionTree has group but not allocated to any Question
        /// </summary>
        /// <param name="questionTree"></param>
        private static void ValidateGroupHasNoQuestions(Model.Schema.QuestionTree questionTree)
        {
            foreach (
                var questionGroup in
                    questionTree.Groups.Where(
                        questionGroup =>
                        !questionTree.Questions.Any(x => x.GroupCode.ToLower() == questionGroup.Code.ToLower())))
            {
                throw new Exception("QuestionTree has group but not allocated to any Question. Group:" +
                                    questionGroup.Code);
            }
        }

        #endregion
    }
}