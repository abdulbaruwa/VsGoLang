﻿using System;

namespace Pelican.QuestionTree.Configuration
{
    public class QuestionTreeConfigurationSettings : IQuestionTreeConfigurationSettings
    {
        #region IQuestionTreeConfigurationSettings Members

        public string QuestionTreeJsonFilePath
        {
            get { return "QuestionTreeSchema.json"; }
        }

        public int LookupCountforRadioButon
        {
            get { return 3; }
        }

        public string DefaultQuestionGroupDescription
        {
            get { return "Misc"; }
        }

        #endregion
    }
}