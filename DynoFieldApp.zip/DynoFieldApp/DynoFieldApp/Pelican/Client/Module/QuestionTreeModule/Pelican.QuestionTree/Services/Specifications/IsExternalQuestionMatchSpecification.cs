﻿using Pelican.QuestionTree.Model;

namespace Pelican.QuestionTree.Services.Specifications
{
    public class IsExternalQuestionMatchSpecification : AbstractSpecification
    {
        private readonly Filter _filter;
        private readonly Visit _visit;

        public IsExternalQuestionMatchSpecification(Filter filter, Visit visit)
        {
            _visit = visit;
            _filter = filter;
        }

        public override bool IsSatisfied()
        {
            if (_visit.Questionnaires == null) return false;

            var contextQuestionnaire = _visit.Questionnaires.FirstOrDefault(x => x.Code == _filter.LinkedQuestionnaireCode);

            if (contextQuestionnaire == null) return false;

            var response = contextQuestionnaire.Responses.FirstOrDefault(x => x.Code == _filter.LinkedQuestionCode);

            if (response == null) return false;

            return response.Value == _filter.MatchValueFrom;
        }
    }
}
