﻿using System;
using System.IO;
using System.Text;

namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public class ConditionLexer : IConditionLexer
    {
        private TextReader _textReader;

        private int _position = 0;

        public void Build(TextReader textReader)
        {
            _textReader = textReader;
        }

        public Token CurrentToken { get; private set; }

        public Token NextToken()
        {
            CurrentToken = Next();
            return CurrentToken;
        }

        private Token Next()
        {
            int nextChar;

            while ((nextChar = ReaderRead()) != -1)
            {
                switch (nextChar)
                {
                    case ' ':
                        continue;
                    case '[':
                        return ReadFilterCondition();
                    case '(':
                        return new Token(Tokens.OpenParenthesis, _position, "(");
                    case ')':
                        return new Token(Tokens.CloseParenthesis, _position, ")");
                    default:
                        return ReadKeyword((char) nextChar);
                }
            }

            return new Token(Tokens.Eof, 0, "Eof");
        }

        #region Private Helper Methods

        private Token ReadKeyword(char firstChar)
        {
            int startPosition = _position;

            var potentialKeywordBuilder = new StringBuilder();
            potentialKeywordBuilder.Append(firstChar);

            while (true) // Continue reading until a character other than a letter or number is found
            {
                var peek = _textReader.Peek();

                if (!char.IsLetterOrDigit((char)peek)) break;
               
                potentialKeywordBuilder.Append((char)ReaderRead());
            }

            int keyWordToken = Keywords.GetToken(potentialKeywordBuilder.ToString().ToLower());

            if (keyWordToken <= 0)
                throw new InvalidOperationException(String.Format("Unexpected keyword {0} found at position {1}", potentialKeywordBuilder, startPosition));

            return new Token(keyWordToken, startPosition, potentialKeywordBuilder.ToString());
        }

        private Token ReadFilterCondition()
        {
            int startPosition = _position;
            int nextChar;
            bool doneNormally = false; 
            var filterConditionBuilder = new StringBuilder();

            while ((nextChar = ReaderRead()) != -1)
            {
                var ch = (char) nextChar;

                if (ch == ']')
                {
                    doneNormally = true;
                    break;
                }

                filterConditionBuilder.Append(ch);
            }

            if (!doneNormally) throw new InvalidOperationException("Found unclosed filter condition at position " + startPosition);

            return new Token(Tokens.FilterCondition, startPosition, filterConditionBuilder.ToString().ToLower());
        }

        private int ReaderRead()
        {
            _position++;
            return _textReader.Read();
        }

        #endregion
    }
}
