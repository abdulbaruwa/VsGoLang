﻿namespace Pelican.QuestionTree.Configuration
{
    public interface IQuestionTreeConfigurationSettings
    {
        string QuestionTreeJsonFilePath { get; }
        int LookupCountforRadioButon { get; }
        string DefaultQuestionGroupDescription { get; }
    }
}
