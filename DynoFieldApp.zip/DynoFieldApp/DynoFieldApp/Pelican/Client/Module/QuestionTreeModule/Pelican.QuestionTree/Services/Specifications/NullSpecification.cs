﻿using System;

namespace Pelican.QuestionTree.Services.Specifications
{
    public class NullSpecification : ISpecification
    {
        public bool HasValue
        {
            get { return true; }
        }

        public bool IsSatisfied()
        {
            return true;
        }

        public ISpecification And(ISpecification other)
        {
            throw new NotImplementedException();
        }

        public ISpecification Or(ISpecification other)
        {
            throw new NotImplementedException();
        }

        public ISpecification Not()
        {
            throw new NotImplementedException();
        }
    }
}
