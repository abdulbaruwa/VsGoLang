﻿namespace Pelican.QuestionTree.Configuration
{
    public interface IAutoMapperConfiguration
    {
        void Configure();
    }
}