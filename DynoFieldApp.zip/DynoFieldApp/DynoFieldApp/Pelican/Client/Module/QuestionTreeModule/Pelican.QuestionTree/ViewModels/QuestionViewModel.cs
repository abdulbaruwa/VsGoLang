﻿using System;
using Pelican.Common.MVVM;
using Pelican.QuestionTree.Services.Specifications;
using Pelican.QuestionTree.ViewModels.Responses;

namespace Pelican.QuestionTree.ViewModels
{
    public class QuestionViewModel : ValidatingViewModelBase<QuestionViewModel>, IQuestionViewModel
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public bool Mandatory { get; set; }
        public string Tooltip { get; set; }
        public bool NotesRequired { get; set; }

        public AbstractResponse Response { get; set; }
        public string NotesValue { get; set; }

        public ISpecification ShowSpecification { get; set; }

        public Boolean Show
        {
            get
            {
                if (ShowSpecification == null)
                    return true;

                return ShowSpecification.IsSatisfied();
            }
        }
    }

    public interface IQuestionViewModel
    {
        string Code { get; set; }
        string Description { get; set; }
        bool Mandatory { get; set; }
        string Tooltip { get; set; }
        bool NotesRequired { get; set; }
        AbstractResponse Response { get; set; }
        string NotesValue { get; set; }
        ISpecification ShowSpecification { get; set; }
        Boolean Show { get; }
    }
}