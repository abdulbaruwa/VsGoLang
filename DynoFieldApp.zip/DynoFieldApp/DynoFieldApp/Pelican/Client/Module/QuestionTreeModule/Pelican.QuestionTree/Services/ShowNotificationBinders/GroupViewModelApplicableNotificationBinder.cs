﻿using System.Collections.Generic;
using System.ComponentModel;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.ShowNotificationBinders
{
    public class GroupViewModelApplicableNotificationBinder : IGroupViewModelApplicableNotificationBinder
    {
        #region IGroupApplicableNotificationBinder Members

        public void Bind(IList<GroupViewModel> groupViewModels)
        {
            foreach (GroupViewModel model in groupViewModels)
            {
                foreach (QuestionViewModel questionViewModel in model.QuestionViewModels)
                {
                    GroupViewModel groupViewModel = model;

                    questionViewModel.PropertyChanged += delegate(object sender, PropertyChangedEventArgs e)
                                                             {
                                                                 if (e.PropertyName == "Show")
                                                                 {
                                                                     groupViewModel.RaiseQuestionShowNotificationChanged();
                                                                 }
                                                             };
                }
            }
        }

        #endregion
    }
}