﻿namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public class Token  
    {
        public Token(int kind, int column, string value)
        {
            Kind = kind;
            Position = column;
            Value = value;
        }

        public int Kind { get; private set; }

        public int Position { get; private set; }

        public string Value { get; private set; }
    }
}