﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.ViewModels
{
    public interface IQuestionTreeSchemaViewModel
    {
        List<QuestionTreeViewModel> QuestionTreeViewModels { get; set; }
    }
}