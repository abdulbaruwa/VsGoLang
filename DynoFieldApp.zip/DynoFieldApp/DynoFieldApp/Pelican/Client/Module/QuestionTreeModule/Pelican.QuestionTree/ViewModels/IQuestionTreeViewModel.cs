﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.ViewModels
{
    public interface IQuestionTreeViewModel
    {
        string Code { get; set; }
        string Description { get; set; }
        List<GroupViewModel> GroupViewModels { get; set; }
    }
}