﻿using Pelican.QuestionTree.Model;

namespace Pelican.QuestionTree.ViewModels.Responses
{
    public class RadiobuttonResponse : LookupResponseBase
    {
      
    }
}