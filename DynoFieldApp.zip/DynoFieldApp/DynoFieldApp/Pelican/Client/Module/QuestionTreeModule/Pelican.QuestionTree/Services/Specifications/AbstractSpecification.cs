﻿namespace Pelican.QuestionTree.Services.Specifications
{
    public abstract class AbstractSpecification : ISpecification
    {
        #region ISpecification Members

        public abstract bool IsSatisfied();

        public virtual bool HasValue
        {
            get { return true; }
        }

        public ISpecification And(ISpecification other)
        {
            return new AndSpecification(this, other);
        }

        public ISpecification Or(ISpecification other)
        {
            return new OrSpecification(this, other);
        }

        #endregion
    }
}