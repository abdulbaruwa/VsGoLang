﻿using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.Specifications
{
    public class IsQuestionMatchSpecification : AbstractSpecification
    {
        public IQuestionViewModel RelatedQuestion
        {
            get { return _relatedQuestion; }
        }

        public override bool HasValue
        {
            get { return !string.IsNullOrEmpty(_relatedQuestion.Response.Value); }
        }

        private readonly IQuestionViewModel _relatedQuestion;
        private readonly string _matchValueFrom;
        private readonly string _matchValueTo;


        public IsQuestionMatchSpecification(IQuestionViewModel relatedQuestion, string questionMatchValueFrom, string questionMatchValueTo)
        {
            _matchValueFrom = questionMatchValueFrom;
            _matchValueTo = questionMatchValueTo;
            _relatedQuestion = relatedQuestion;
        }
        
        public override bool IsSatisfied()
        {
            if (!_relatedQuestion.Show) return false;

            if (string.IsNullOrEmpty(_matchValueTo))
                return _relatedQuestion.Response.Value == _matchValueFrom;

            return IsRangeValid();

        }

        private bool IsRangeValid()
        {
            return string.Compare(_relatedQuestion.Response.Value, _matchValueFrom) >= 0 &&
                   string.Compare(_relatedQuestion.Response.Value, _matchValueTo) <= 0;
        }
    }
}