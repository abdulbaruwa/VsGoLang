﻿using System.Collections.Generic;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.ShowNotificationBinders
{
    public interface IGroupViewModelApplicableNotificationBinder
    {
        void Bind(IList<GroupViewModel> groupViewModels);
    }
}