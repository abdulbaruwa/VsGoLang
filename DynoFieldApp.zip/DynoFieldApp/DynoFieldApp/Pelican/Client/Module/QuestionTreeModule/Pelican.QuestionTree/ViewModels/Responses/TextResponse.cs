﻿namespace Pelican.QuestionTree.ViewModels.Responses
{
    public class TextResponse : AbstractResponse
    {
    }
}