﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Services.ShowNotificationBinders;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services
{
    public class QuestionTreeViewModelBuilder : IQuestionTreeViewModelBuilder
    {
        private readonly IQuestionTreeSchemaRetriever _questionTreeSchemaRetriever;
        private readonly IGroupViewModelApplicableNotificationBinder _groupViewModelApplicableNotificationBinder;

        #region Constructor

        public QuestionTreeViewModelBuilder(IQuestionTreeSchemaRetriever questionTreeSchemaRetriever, IGroupViewModelApplicableNotificationBinder groupViewModelApplicableNotificationBinder)
        {
            _questionTreeSchemaRetriever = questionTreeSchemaRetriever;
            _groupViewModelApplicableNotificationBinder = groupViewModelApplicableNotificationBinder;
        }

        #endregion

        #region IQuestionTreeViewModelBuilder Members

        public IQuestionTreeViewModel Build(string questionTreeCode)
        {
            var questionTreeSchema = _questionTreeSchemaRetriever.QuestionTreeSchema;
            var questionTree = questionTreeSchema.QuestionTrees.FirstOrDefault(x => x.Code.ToLower() == questionTreeCode.ToString().ToLower());
            
            if (questionTree == null) 
                throw new Exception(string.Format("QuestionTree does not exists. QuestionTree:{0}", questionTreeCode));
            
            IQuestionTreeViewModel questionTreeViewModel = Mapper.Map<Model.Schema.QuestionTree, QuestionTreeViewModel>(questionTree);
            _groupViewModelApplicableNotificationBinder.Bind(questionTreeViewModel.GroupViewModels);
            return questionTreeViewModel;
        }

        #endregion
    }

    
}