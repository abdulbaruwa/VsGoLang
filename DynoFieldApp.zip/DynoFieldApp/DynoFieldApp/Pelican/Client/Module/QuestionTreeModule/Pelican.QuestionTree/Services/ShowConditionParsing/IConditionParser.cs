﻿using System.Collections.Generic;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;
using Pelican.QuestionTree.Services.Specifications;
using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services.ShowConditionParsing
{
    public interface IConditionParser
    {
        ISpecification Parse(Question question, QuestionViewModel questionViewModel);
    }
}