﻿namespace Pelican.QuestionTree.Services.Specifications
{
    public interface ISpecification
    {
        bool HasValue { get; }
        bool IsSatisfied();
        ISpecification And(ISpecification other);
        ISpecification Or(ISpecification other);
    }
}
