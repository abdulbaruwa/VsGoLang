﻿using Pelican.QuestionTree.ViewModels;

namespace Pelican.QuestionTree.Services
{
    public interface IQuestionTreeViewModelBuilder          
    {
        IQuestionTreeViewModel Build(string questionTreeCode);
    }
}