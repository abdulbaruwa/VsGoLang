﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;

namespace Pelican.QuestionTree.ViewModels.Responses
{
    public class LookupResponseBase : AbstractResponse
    {
        public LookupGroup LookupGroup { get; set; }
    }
}
