﻿using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;

namespace Pelican.QuestionTree.Services
{
    public interface IQuestionTreeSchemaRetriever
    {
        QuestionTreeSchema QuestionTreeSchema { get; } 
    }
}