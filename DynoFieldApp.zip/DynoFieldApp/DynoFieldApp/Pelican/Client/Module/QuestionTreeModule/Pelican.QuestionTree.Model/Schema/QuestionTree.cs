﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.Model.Schema
{
    public class QuestionTree
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public List<Question> Questions { get; set; }
        public List<Group> Groups { get; set; }
    }
}