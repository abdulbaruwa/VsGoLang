﻿namespace Pelican.QuestionTree.Model.Schema
{
    public class Question
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public QuestionDataType QuestionDataType { get; set; }
        public string GroupCode { get; set; }
        public string FilterConditionCode { get; set; }
        public string Tooltip { get; set; }
        public bool Mandatory { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public string LookupGroupCode { get; set; }
        public bool NotesRequired { get; set; }
    }
}