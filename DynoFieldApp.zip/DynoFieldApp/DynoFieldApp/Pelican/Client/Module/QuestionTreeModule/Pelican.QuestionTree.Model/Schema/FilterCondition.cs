﻿namespace Pelican.QuestionTree.Model.Schema
{
    public class FilterCondition
    {
        public string Code { get; set; }
        public string Condition { get; set; }
    }
}