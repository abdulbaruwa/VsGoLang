﻿namespace Pelican.QuestionTree.Model.Schema
{
    public class Group
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}