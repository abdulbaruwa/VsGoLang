﻿namespace Pelican.QuestionTree.Model.Context
{
    public class Answer
    {
        public string QuestionCode { get; set; }

        public object Value { get; set; }
    }
}