﻿namespace Pelican.QuestionTree.Model.Schema
{
    public class Filter
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string FromValue { get; set; }
        public string ToValue { get; set; }
        public string LinkQuestionCode { get; set; }
        public string LinkQuestionTreeCode { get; set; }
    }
}