﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.Model.Context
{
    public class QuestionTreeContext
    {
        public List<QuestionTreeData> QuestionTreeDatas { get; set; }
    }

    public class QuestionTreeData
    {
        public string Code { get; set; }

        public List<Answer> Answers { get; set; }
    }
}
