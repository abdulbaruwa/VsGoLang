﻿namespace Pelican.QuestionTree.Model.Schema
{
    public class Lookup
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string Tooltip { get; set; }
        public string FilterConditionCode { get; set; }
    }
}