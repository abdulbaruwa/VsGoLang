﻿namespace Pelican.QuestionTree.Model.Schema
{
    public enum QuestionDataType
    {
        Text = 1,
        Integer = 2,
        Decimal = 3,
        Lookup = 4,
        Boolean = 5,
        Photo = 6,
        Drawing = 7,
        Signature = 8,
        Date = 9,
        DateTime = 10

    }
}