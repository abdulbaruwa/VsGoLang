﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.Model.Schema
{
    public class LookupGroup
    {
        public string Code { get; set; }
        public List<Lookup> Lookups { get; set; }
    }
}