﻿using System.Collections.Generic;

namespace Pelican.QuestionTree.Model.Schema
{
    public class QuestionTreeSchema
    {
        public List<FilterCondition> Conditions { get; set; }
        public List<LookupGroup> LookupGroups { get; set; }
        public List<Filter> Filters { get; set; }
        public List<Schema.QuestionTree> QuestionTrees { get; set; }
    }
}
