﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace Pelican.QuestionTree.Features.StepDefinitions
{
    [Binding]
    public class QuestionTreeSteps
    {
        [Given(@"the questiontrees")]
        public void GivenTheQuestiontrees(Table table)
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"the questiontree groups")]
        public void GivenTheQuestiontreeGroups(Table table)
        {
            ScenarioContext.Current.Pending();
        }


    }
}
