﻿using Microsoft.Practices.Unity;
using Pelican.QuestionTree.Configuration;
using Pelican.QuestionTree.ViewModels;
using Rhino.Mocks;

namespace Pelican.QuestionTree.Fixtures.Helpers
{
    public static class AutoMapperHelper
    {
        public static void ConfigureAutoMapper()
        {
            var unityContainer = MockRepository.GenerateMock<IUnityContainer>();
            var questionTreeViewModel = new QuestionTreeViewModel();
            unityContainer.Stub(x => x.Resolve<QuestionTreeViewModel>()).Return(questionTreeViewModel);
            var autoMapperConfiguration = new AutoMapperConfiguration();
            autoMapperConfiguration.Configure();
        }
    }
}