﻿using System;
using System.Linq;
using NUnit.Framework;
using Pelican.QuestionTree.Fixtures.Configuration;
using Pelican.QuestionTree.Model;
using Pelican.QuestionTree.Model.Schema;
using Pelican.QuestionTree.Services;
using Pelican.TestExtensions;

namespace Pelican.QuestionTree.Fixtures.Services
{
    [System.ComponentModel.Category("UnitTests")]
    [TestFixture]
    public class AllQuestionsLoadedCorrectlyIntegrationTests : SingleRunBaseContext<IQuestionTreeSchemaRetriever>
    {
        private QuestionTreeSchema _result;

        protected override IQuestionTreeSchemaRetriever SetupContext()
        {
            return new QuestionTreeSchemaRetriever(new UnitTestingQuestionTreeConfigurationSettings());
        }

        protected override void Because()
        {
            _result = Sut.QuestionTreeSchema;
        }

        [Test]
        public void ShouldHaveTwoQuestionTrees()
        {
            _result.QuestionTrees.Count.ShouldEqual(2);
        }
        
        [Test]
        public void ShouldHavePopulatedTheQuestionCodeCorrectly()
        {
            _result.QuestionTrees.FirstOrDefault(x => x.Code == "riskassessment").ShouldNotBeNull();
        }

    }
}