﻿using NUnit.Framework;
using Pelican.QuestionTree.Fixtures.Configuration;
using Pelican.QuestionTree.Fixtures.Helpers;
using Pelican.QuestionTree.Services;
using Pelican.QuestionTree.Services.ShowNotificationBinders;
using Pelican.QuestionTree.ViewModels;
using Pelican.TestExtensions;
using Rhino.Mocks;

namespace Pelican.QuestionTree.Fixtures.Services
{
    [System.ComponentModel.Category("UnitTests")]
    [TestFixture]
    public class WhenBuildingUsingAValidQuestionTreeReference : BaseContext<QuestionTreeViewModelBuilder>
    {
        private IQuestionTreeViewModel _result;

        protected override QuestionTreeViewModelBuilder SetupContext()
        {
            AutoMapperHelper.ConfigureAutoMapper();
            //IShowSpecificationBinder showSpecificationBinder = MockRepository.GenerateMock<ShowSpecificationBinder>();
            return new QuestionTreeViewModelBuilder(new QuestionTreeSchemaRetriever(new UnitTestingQuestionTreeConfigurationSettings()), new GroupViewModelApplicableNotificationBinder());
        }

        protected override void Because()
        {
            _result = Sut.Build("RiskAssessment");
        }

        [Test]
        public void ShouldHaveTheGroups()
        {
            _result.GroupViewModels.Count.ShouldNotBeNull();
        }

        [Test]
        public void ShouldHaveTheQuestionsLoadedIntoGroup()
        {
            _result.GroupViewModels[0].QuestionViewModels.Count.ShouldBeGreaterThan(1);
        }

        [Test]
        public void ShouldHaveTheRiskAssessmentQuestionTreeCode()
        {
            _result.Code.ToLower().ShouldEqual("riskassessment");
        }


        #region Groups
        
        [Test]
        public void ShouldNotShowTheGroupWhenAllQuestionAreHidden()
        {
            _result.GroupViewModels[0].IsEnabled.ShouldBeFalse();
        }

        #endregion
    }
}