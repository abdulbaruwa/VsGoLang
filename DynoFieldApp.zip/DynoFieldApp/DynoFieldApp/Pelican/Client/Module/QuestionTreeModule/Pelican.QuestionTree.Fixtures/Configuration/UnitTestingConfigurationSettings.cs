﻿using System;
using Pelican.QuestionTree.Configuration;

namespace Pelican.QuestionTree.Fixtures.Configuration
{
    public class UnitTestingQuestionTreeConfigurationSettings : IQuestionTreeConfigurationSettings
    {
        #region IConfigurationSettings Members

        public string QuestionTreeJsonFilePath
        {
            get { return @"Fakes\FakeQuestionTreeSchema.json"; }
        }

        public int LookupCountforRadioButon
        {
            get { return 3; }
        }

        public string DefaultQuestionGroupDescription
        {
            get { return "Misc"; }
        }

        #endregion
    }
}