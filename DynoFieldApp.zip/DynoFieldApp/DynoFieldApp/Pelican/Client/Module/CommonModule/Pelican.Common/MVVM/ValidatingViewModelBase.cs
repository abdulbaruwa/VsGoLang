﻿namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents a base ViewModel object that implements field validation.
    /// </summary>
    /// <typeparam name="TData">The data class used by this ViewModel</typeparam>
    public abstract class ValidatingViewModelBase<TData> : ViewModelBase<TData>, IValidatingViewModel where TData : class
    {
        public virtual bool IsValid
        {
            get { return string.IsNullOrEmpty(Error); }
        }

        #region IDataErrorInfo Members

        public virtual string Error
        {
            get { return this[string.Empty]; }
        }

        public virtual string this[string columnName]
        {
            get { return string.Empty; }
        }
        

        #endregion
    }
}
