﻿namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents an interface to a ViewModel object, containing a View object.
    /// </summary>
    public interface IViewModel
    {
        /// <summary>
        /// The View that is bound to this ViewModel
        /// </summary>
        object View { get; set; }

        /// <summary>
        /// The ViewModel that is the logical parent of this ViewModel
        /// </summary>
        IViewModel Parent { get; set; }

        /// <summary>
        /// Determines whether the View should be enabled
        /// </summary>
        bool IsEnabled { get; set; }
        
        /// <summary>
        /// Determines whether the View should be visible
        /// </summary>
        bool IsVisible { get; set; }

        /// <summary>
        /// Called when the ViewModel is activated (gain focus)
        /// </summary>
        void Activate();

        /// <summary>
        /// Called when the ViewModel is deactivated (lost focus)
        /// </summary>
        void Deactivate();

        /// <summary>
        /// Refreshes all items in the View that are bound to this ViewModel
        /// </summary>
        void RefreshAllBindings();
    }


    public interface IViewModel<TData> : IViewModel
    {
        /// <summary>
        /// The data model entity this ViewModel uses to populate the UI
        /// </summary>
        TData DataModelEntity { get; set; }

        /// <summary>
        /// Called when the DataModel changes and the ViewModel needs to refresh the UI.
        /// </summary>
        /// <param name="dataModelEntity"></param>
        void LoadDataModel(TData dataModelEntity);
    }
}
