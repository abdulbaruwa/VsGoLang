﻿using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;

namespace Pelican.Common.Serialization
{
    public class JSONSerializer
    {
        public static T Deserialize<T>(string json)
        {
            var obj = Activator.CreateInstance<T>();
            using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(json)))
            {
                var serializer = new DataContractJsonSerializer(obj.GetType());
                obj = (T) serializer.ReadObject(ms);
                ms.Close();
                ms.Dispose();
            }
            return obj;
        }


        public static string Serialize(object objectInstance)
        {
            var stream = new MemoryStream();
            var jsonSerializer = new DataContractJsonSerializer(objectInstance.GetType());
            jsonSerializer.WriteObject(stream, objectInstance);
            stream.Position = 0;
            var streamreader = new StreamReader(stream);
            var result = streamreader.ReadToEnd();
            return result;
        }

        public static T DeserializeFromJson<T>(string data)
        {
            var jsonSerializer = new DataContractJsonSerializer(typeof(T));
            var bytesarray = Encoding.UTF8.GetBytes(data);
            using (var stream = new MemoryStream(bytesarray))
            {
                var objectInstance = (T)jsonSerializer.ReadObject(stream);
                return objectInstance;
            }
        }
    }
}