﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;

namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents a base ViewModel object that can also have 'child' ViewModels, as a TabControl contains child TabPages.
    /// A HierarchicalViewModel can in turn be the parent of further HierarchicalViewModels to form a composite 'tree' of ViewModels.
    /// </summary>
    /// <typeparam name="TData">The data class used by this ViewModel</typeparam>
    public class HierarchicalViewModelBase<TData> : ValidatingViewModelBase<TData>, IHierarchicalViewModel where TData : class
    {
        #region properties

        /// <summary>
        /// Can we ignore validation errors and execute Next or Previous command when Child ViewModel has validation errors
        /// </summary>
        public bool CanIgnoreValidationErrorsForNextAndPrevious { get; set; }

        /// <summary>
        /// Can we delay validation for the Next and Previous commands until we try to execute the Next or Previous command.
        /// This will result in the CanExecute returning true even with errors, but the Execute command will fail.
        /// </summary>
        public bool CanDelayValidationUntilExecution { get; set; }

        #endregion properties


        #region child ViewModels

        /// <summary>
        /// Contains a list of the Child ViewModels of this ViewModel
        /// </summary>
        public List<IViewModel> ChildViewModels { get; set; }

        /// <summary>
        /// Gets or Sets the selected Child ViewModel
        /// </summary>
        private IViewModel _selectedChild;
        public IViewModel SelectedChild
        {
            get
            {
                if (_selectedChild == null && ChildViewModels.Count > 0)
                {
                    _selectedChild = ChildViewModels[0];
                }
                return _selectedChild;
            }
            set
            {
                if (value != null && !ChildViewModels.Contains(value)) return;

                if (_selectedChild == value) return;

                if (_selectedChild != null) _selectedChild.Deactivate();

                _selectedChild = value;

                if (_selectedChild != null) _selectedChild.Activate();

                NotifyOfPropertyChange(() => SelectedChild);
            }
        }

        /// <summary>
        /// Returns whether this ViewModel has any Children
        /// </summary>
        public bool HasChildren
        {
            get { return ChildViewModels.Count > 0; }
        }

        /// <summary>
        /// Add a Child View Model and make Parent/Child link
        /// </summary>
        /// <param name="child"></param>
        public virtual void AddChild(IViewModel child)
        {
            child.Parent = this;
            ChildViewModels.Add(child);
        }

        #endregion child ViewModels


        #region commands

        private ICommand _nextCommand;
        private ICommand _previousCommand;

        /// <summary>
        /// Command to move to the Next child
        /// </summary>
        public virtual ICommand NextCommand
        {
            get { return _nextCommand ?? (_nextCommand = new RelayCommand(action => MoveNext(), predicate => CanMoveNext())); }
        }

        /// <summary>
        /// Command to move to the Previous child
        /// </summary>
        public virtual ICommand PreviousCommand
        {
            get { return _previousCommand ?? (_previousCommand = new RelayCommand(action => MovePrevious(), predicate => CanMovePrevious())); }
        }

        #endregion commands


        #region constructors

        public HierarchicalViewModelBase()
        {
            ChildViewModels = new List<IViewModel>();
            OnInitialiseDefaults();
        }
        
        private void OnInitialiseDefaults()
        {
            InitialiseDefaults();
        }

        /// <summary>
        /// Initialises controlling properties on construction
        /// </summary>
        protected virtual void InitialiseDefaults()
        {
            CanIgnoreValidationErrorsForNextAndPrevious = false;
            CanDelayValidationUntilExecution = true;
        }

        #endregion constructors


        #region command handlers for Next and Previous Child

        /// <summary>
        /// Can we move forward to the 'next' child
        /// </summary>
        /// <returns></returns>
        protected virtual bool CanMoveNext()
        {
            return CanTryMoveNext(CanDelayValidationUntilExecution);
        }

        /// <summary>
        /// Can we move forward to the 'next' child
        /// </summary>
        /// <param name="delayValidation">True if delaying the validation step until execution time. 
        /// This will allow the command to be enabled, even if validation errors exist.</param>
        /// <returns></returns>
        private bool CanTryMoveNext(bool delayValidation)
        {
            if (SelectedChild == null)
                return false;

            //if we cannot delay validation and cannot ignore errors, then ensure the selected child is valid
            if (!delayValidation && !CanIgnoreValidationErrorsForNextAndPrevious && !IsSelectedChildValid())
                return false;

            //get a list of the children that are visible and enabled
            var availableChildren = GetAvailableChildren();

            //are we on the final available tab
            if (availableChildren.IndexOf(SelectedChild) >= availableChildren.Count - 1)
                return false;

            return true;
        }

        /// <summary>
        /// Can we move backwards to the 'previous' child
        /// </summary>
        /// <returns></returns>
        protected virtual bool CanMovePrevious()
        {
            return CanTryMovePrevious(CanDelayValidationUntilExecution);
        }

        /// <summary>
        /// Can we move backwards to the 'previous' child
        /// </summary>
        /// <param name="delayValidation">True if delaying the validation step until execution time. 
        /// This will allow the command to be enabled, even if validation errors exist.</param>
        /// <returns></returns>
        private bool CanTryMovePrevious(bool delayValidation)
        {
            if (SelectedChild == null)
                return false;

            //if we cannot delay validation and cannot ignore errors, then ensure the selected child is valid
            if (!delayValidation && !CanIgnoreValidationErrorsForNextAndPrevious && !IsSelectedChildValid())
                return false;

            //get a list of the children that are visible and enabled
            var availableChildren = GetAvailableChildren();

            //are we on the first available tab
            if (availableChildren.IndexOf(SelectedChild) <= 0)
                return false;

            return true;
        }

        /// <summary>
        /// Go to the next available child
        /// </summary>
        protected virtual void MoveNext()
        {
            if (!CanTryMoveNext(false))
                return;

            //if we cannot ignore errors, then ensure the selected child is valid
            if (!CanIgnoreValidationErrorsForNextAndPrevious && !IsSelectedChildValid())
                return;

            //get a list of the children that are visible and enabled
            var availableChildren = GetAvailableChildren(); 

            //get the index of the current child
            var current = availableChildren.IndexOf(SelectedChild);

            //get the next available child
            var next = availableChildren[current + 1];

            //make this the new 'selected' child
            if (next != null)
                SelectedChild = next;
        }

        /// <summary>
        /// Go to the previous available child
        /// </summary>
        protected virtual void MovePrevious()
        {
            if (!CanTryMovePrevious(false))
                return;

            //if we cannot ignore errors, then ensure the selected child is valid
            if (!CanIgnoreValidationErrorsForNextAndPrevious && !IsSelectedChildValid())
                return;

            //get a list of the children that are visible and enabled
            var availableChildren = GetAvailableChildren();

            //get the index of the current child
            var current = availableChildren.IndexOf(SelectedChild);

            //get the previous available child
            var previous = availableChildren[current - 1];

            //make this the new 'selected' child
            if (previous != null)
                SelectedChild = previous;
        }

        /// <summary>
        /// returns a list of Child ViewModels that are both Visible & Enabled
        /// </summary>
        /// <returns></returns>
        private IList<IViewModel> GetAvailableChildren()
        {
            return ChildViewModels.Where(x => x.IsVisible && x.IsEnabled).ToList();
        }

        #endregion command handlers for Next and Previous Child


        #region overrides

        /// <summary>
        /// Activate the 'selected' Child ViewModel
        /// </summary>
        public override void Activate()
        {
            base.Activate();

            //activate selected Child ViewModel
            if (SelectedChild != null)
            {
                SelectedChild.Activate();
            }
        }

        /// <summary>
        /// Ensure each of the Child ViewModels are valid
        /// </summary>
        public override bool IsValid
        {
            get
            {
                foreach (var childViewModel in GetAvailableChildren())
                {
                    if (childViewModel is IValidatingViewModel)
                    {
                        if (!((IValidatingViewModel)childViewModel).IsValid)
                            return false;
                    }
                }
                return true;
            }
        }

        #endregion overrides


        #region private & protected methods

        /// <summary>
        /// If the selected child is a validating ViewModel, does it satisfy validation rules.
        /// </summary>
        /// <returns></returns>
        protected virtual bool IsSelectedChildValid()
        {
            if (SelectedChild is IValidatingViewModel)
            {
                return ((IValidatingViewModel) SelectedChild).IsValid;
            }

            return true;
        }

        #endregion private & protected methods
    }
}
