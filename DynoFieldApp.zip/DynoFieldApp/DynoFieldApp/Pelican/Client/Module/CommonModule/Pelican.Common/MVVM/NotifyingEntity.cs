﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;

namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents an abstract base class to handle property change notification.
    /// </summary>
    public abstract class NotifyingEntity : INotifyPropertyChanged
    {
        /// <summary>
        /// Call using 'NotifyOfPropertyChange(() => MyPropertyName);'
        /// </summary>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="property"></param>
        public void NotifyOfPropertyChange<TProperty>(Expression<Func<TProperty>> property)
        {
            var lambda = (LambdaExpression)property;
            var memberExpression = (MemberExpression)lambda.Body;
            NotifyOfPropertyChange(memberExpression.Member.Name);
        }

        /// <summary>
        /// /// Call using 'NotifyOfPropertyChange("MyPropertyName");'
        /// </summary>
        /// <param name="propertyName"></param>
        public void NotifyOfPropertyChange(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion INotifyPropertyChanged
    }
}
