﻿namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents a base ViewModel object, containing a View object.
    /// This ViewModel object could be Parented by another IViewModel.
    /// </summary>
    public class ViewModelBase : NotifyingEntity, IViewModel
    {
        private bool _isEnabled = true;
        private bool _isVisible = true;

        /// <summary>
        /// The View that is bound to this ViewModel
        /// </summary>
        public object View { get; set; }

        /// <summary>
        /// The ViewModel that is the logical parent of this ViewModel
        /// </summary>
        public IViewModel Parent { get; set; }

        /// <summary>
        /// Determines whether the View should be enabled
        /// </summary>
        public virtual bool IsEnabled
        {
            get { return View != null && _isEnabled; }
            set {
                if (_isEnabled == value) return;
                _isEnabled = value;
                NotifyOfPropertyChange(() => IsEnabled);
            }
        }

        /// <summary>
        /// Determines whether the View should be shown
        /// </summary>
        public bool IsVisible
        {
            get { return View != null && _isVisible; }
            set
            {
                if (_isVisible == value) return;
                _isVisible = value;
                NotifyOfPropertyChange(() => IsVisible);
            }
        }

        /// <summary>
        /// Called when the ViewModel is activated (gain focus)
        /// </summary>
        public virtual void Activate()
        { }

        /// <summary>
        /// /// Called when the ViewModel is deactivated (lose focus)
        /// </summary>
        public virtual void Deactivate()
        { }

        /// <summary>
        /// Refreshes all items in the View that are bound to this ViewModel
        /// </summary>
        public void RefreshAllBindings()
        {
            NotifyOfPropertyChange("");
        }
    }


    /// <summary>
    /// Represents a base ViewModel object that will be loaded with data of specified type TData.
    /// </summary>
    /// <typeparam name="TData">The data class used by this ViewModel</typeparam>
    public class ViewModelBase<TData> : ViewModelBase, IViewModel<TData> where TData : class
    {
        /// <summary>
        /// The data model entity this ViewModel uses to populate the UI
        /// </summary>
        public TData DataModelEntity { get; set; }

        /// <summary>
        /// Called when the data model changes and the ViewModel needs to refresh the UI
        /// </summary>
        /// <param name="dataModelEntity"></param>
        public void LoadDataModel(TData dataModelEntity)
        {
            var isFirstTime = (DataModelEntity == null);

            DataModelEntity = dataModelEntity;
            DataModelLoaded(isFirstTime);
        }
        
        /// <summary>
        /// Called immediately after the DataModel has been set in the ViewModel
        /// </summary>
        /// <param name="isFirstTime">Is the data model be loaded for the the first time</param>
        protected virtual void DataModelLoaded(bool isFirstTime)
        { }
    }
}
