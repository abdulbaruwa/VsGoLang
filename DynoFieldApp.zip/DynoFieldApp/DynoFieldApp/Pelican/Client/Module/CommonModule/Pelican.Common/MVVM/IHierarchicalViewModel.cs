﻿using System.Collections.Generic;
using System.Windows.Input;

namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents an interface to a ViewModel object that can also have 'child' ViewModels.
    /// </summary>
    public interface IHierarchicalViewModel
    {
        /// <summary>
        /// Contains a list of the Child ViewModels of this ViewModel
        /// </summary>
        List<IViewModel> ChildViewModels { get; set; }

        /// <summary>
        /// Gets or Sets the selected Child ViewModel
        /// </summary>
        IViewModel SelectedChild { get; set; }

        /// <summary>
        /// Returns whether this ViewModel has any Children
        /// </summary>
        bool HasChildren { get; }

        /// <summary>
        /// Add a Child View Model and make Parent/Child link
        /// </summary>
        /// <param name="child"></param>
        void AddChild(IViewModel child);

        /// <summary>
        /// Can we ignore validation errors and execute Next or Previous command when Child ViewModel has validation errors
        /// </summary>
        bool CanIgnoreValidationErrorsForNextAndPrevious { get; set; }

        /// <summary>
        /// Can we delay validation for the Next and Previous commands until we try to execute the Next or Previous command.
        /// This will result in the CanExecute returning true even with errors, but the Execute command will fail.
        /// </summary>
        bool CanDelayValidationUntilExecution { get; set; }

        /// <summary>
        /// Command handler to move to the Next child
        /// </summary>
        ICommand NextCommand { get; }

        /// <summary>
        /// Command handler to move to the Previous child
        /// </summary>
        ICommand PreviousCommand { get; }
    }
}
