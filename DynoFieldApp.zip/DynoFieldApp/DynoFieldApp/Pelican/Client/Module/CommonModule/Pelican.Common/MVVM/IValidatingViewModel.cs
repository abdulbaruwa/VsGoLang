﻿using System.ComponentModel;

namespace Pelican.Common.MVVM
{
    /// <summary>
    /// Represents an interface to a ViewModel object that implements field validation.
    /// </summary>
    public interface IValidatingViewModel : IDataErrorInfo
    {
        bool IsValid { get; }
    }
}
