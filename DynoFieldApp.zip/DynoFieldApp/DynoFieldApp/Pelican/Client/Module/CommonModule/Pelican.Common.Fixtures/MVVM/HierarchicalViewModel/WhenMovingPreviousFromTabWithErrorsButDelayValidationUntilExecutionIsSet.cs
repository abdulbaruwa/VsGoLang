using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenMovingPreviousFromTabWithErrorsButDelayValidationUntilExecutionIsSet : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage2.ErrorMsg = "Field has error.";
            Sut.SelectedChild = Tabpage2;
            Sut.CanDelayValidationUntilExecution = true;

            Sut.PreviousCommand.Execute(null);
        }
        
        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeTrue()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage2()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage2));
        }
    }
}