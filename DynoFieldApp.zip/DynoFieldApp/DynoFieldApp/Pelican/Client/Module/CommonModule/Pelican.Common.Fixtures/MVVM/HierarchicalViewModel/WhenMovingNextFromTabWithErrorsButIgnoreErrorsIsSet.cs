using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenMovingNextFromTabWithErrorsButIgnoreErrorsIsSet : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage1.ErrorMsg = "Field has error.";
            Sut.SelectedChild = Tabpage1;
            Sut.CanIgnoreValidationErrorsForNextAndPrevious = true;

            Sut.NextCommand.Execute(null);
        }


        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeTrue()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage2()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage2));
        }
    }
}