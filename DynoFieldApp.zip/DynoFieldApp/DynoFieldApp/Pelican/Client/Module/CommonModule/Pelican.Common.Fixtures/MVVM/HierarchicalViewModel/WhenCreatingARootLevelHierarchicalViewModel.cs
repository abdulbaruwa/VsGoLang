﻿using NUnit.Framework;
using Pelican.Common.Fixtures.MVVM.Fakes;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCreatingARootLevelHierarchicalViewModel : HierarchicalViewModelFixtureBase
    {
        protected override TabControl SetupContext()
        {
            return new TabControl();
        }

        [Test]
        public void ParentViewModelShouldBeNull()
        {
            Assert.That(Sut.Parent, Is.Null);
        }

        [Test]
        public void ChildViewModelCollectionShouldNotBeNull()
        {
            Assert.That(Sut.ChildViewModels, Is.Not.Null);
        }

        [Test]
        public void ChildViewModelCollectionShouldBeEmpty()
        {
            Assert.That(Sut.ChildViewModels.Count, Is.EqualTo(0));
        }
    }
}
