using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMoveNextFromTabWithError : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage1.ErrorMsg = "Field has error.";
            Sut.CanDelayValidationUntilExecution = false;
            Sut.SelectedChild = Tabpage1;
        }
       
        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }
    }
}