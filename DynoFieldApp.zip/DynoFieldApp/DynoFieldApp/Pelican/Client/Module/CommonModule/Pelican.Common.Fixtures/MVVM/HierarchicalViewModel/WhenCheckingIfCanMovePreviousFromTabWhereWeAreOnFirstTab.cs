using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMovePreviousFromTabWhereWeAreOnFirstTab : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();

            Sut.SelectedChild = Tabpage1;
        }

        [Test]
        public void CanGoNextShouldBeTrue()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void CanGoPreviousShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }
    }
}