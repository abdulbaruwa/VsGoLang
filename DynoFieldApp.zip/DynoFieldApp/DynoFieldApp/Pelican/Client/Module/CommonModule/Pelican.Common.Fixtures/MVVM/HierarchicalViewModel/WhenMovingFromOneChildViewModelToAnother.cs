using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenMovingFromOneChildViewModelToAnother : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();

            Sut.SelectedChild = Tabpage2;
        }

        [Test]
        public void TheSelectedChildShouldBeSet()
        {
            Assert.That(Sut.SelectedChild, Is.Not.Null);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage2()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage2));
        }

        [Test]
        public void TheParentControlShouldBeActivated()
        {
            Assert.That(Sut.ActivateCount, Is.EqualTo(1));
        }

        [Test]
        public void TheTabPage1ControlShouldBeDeactivated()
        {
            Assert.That(Tabpage1.DeactivateCount, Is.EqualTo(1));
        }

        [Test]
        public void TheTabPage2ControlShouldBeActivated()
        {
            Assert.That(Tabpage2.ActivateCount, Is.EqualTo(1));
        }
    }
}