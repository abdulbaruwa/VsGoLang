﻿using Pelican.Common.MVVM;

namespace Pelican.Common.Fixtures.MVVM.Fakes
{
    public class TabControl : HierarchicalViewModelBase<string>
    {
        private int _activateCount = 0;
        private int _deactivateCount = 0;

        public int ActivateCount
        {
            get { return _activateCount; }
            set { _activateCount = value; }
        }

        public int DeactivateCount
        {
            get { return _deactivateCount; }
            set { _deactivateCount = value; }
        }

        public override void Activate()
        {
            base.Activate();
            ActivateCount++;
        }

        public override void Deactivate()
        {
            base.Deactivate();
            DeactivateCount++;
        }
    }
}
