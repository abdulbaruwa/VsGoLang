using NUnit.Framework;
using Pelican.Common.Fixtures.MVVM.Fakes;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCreatingARootLevelHierarchicalViewModelWithChildren : SingleRunBaseContext<TabControl>
    {
        private TabControl _outerTabControl;
        private TabControl _innerTabControl;
        private TabPage _tabpage1;
        private TabPage _tabpage2;

        protected override TabControl SetupContext()
        {
            _outerTabControl = new TabControl();

            _tabpage1 = new TabPage();
            _outerTabControl.AddChild(_tabpage1);

            _tabpage2 = new TabPage();
            _outerTabControl.AddChild(_tabpage2);

            _innerTabControl = new TabControl();
            _outerTabControl.AddChild(_innerTabControl);

            return _outerTabControl;
        }

        protected override void Because()
        {
        }

        [Test]
        public void ChildViewModelCollectionShouldContainThreeItems()
        {
            Assert.That(Sut.ChildViewModels.Count, Is.EqualTo(3));
        }

        [Test]
        public void TabPage1ShouldHaveParent()
        {
            Assert.That(_tabpage1.Parent, Is.Not.Null);
        }

        [Test]
        public void TabPage1ParentShouldBeOuterTabControl()
        {
            Assert.That(_tabpage1.Parent, Is.EqualTo(_outerTabControl));
        }

        [Test]
        public void TabPage2ShouldHaveParent()
        {
            Assert.That(_tabpage2.Parent, Is.Not.Null);
        }

        [Test]
        public void TabPage2ParentShouldBeOuterTabControl()
        {
            Assert.That(_tabpage2.Parent, Is.EqualTo(_outerTabControl));
        }

        [Test]
        public void InnerTabControlShouldHaveParent()
        {
            Assert.That(_innerTabControl.Parent, Is.Not.Null);
        }

        [Test]
        public void InnerTabControlParentShouldBeOuterTabControl()
        {
            Assert.That(_innerTabControl.Parent, Is.EqualTo(_outerTabControl));
        }
    }
}