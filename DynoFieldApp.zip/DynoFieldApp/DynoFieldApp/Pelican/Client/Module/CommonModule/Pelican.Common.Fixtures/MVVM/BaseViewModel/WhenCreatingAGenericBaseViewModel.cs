using NUnit.Framework;
using Pelican.Common.MVVM;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.BaseViewModel
{
    [TestFixture]
    public class WhenCreatingAGenericBaseViewModel : SingleRunBaseContext<ViewModelBase<string>>
    {
        protected override ViewModelBase<string> SetupContext()
        {
            return new ViewModelBase<string>();
        }

        protected override void Because()
        {
        }
        
        [Test]
        public void ViewPropertyShouldBeNull()
        {
            Assert.That(Sut.View, Is.Null);
        }

        [Test]
        public void IsViewEnabledPropertyShouldBeFalse()
        {
            Assert.That(Sut.IsEnabled, Is.EqualTo(false));
        }
    }
}