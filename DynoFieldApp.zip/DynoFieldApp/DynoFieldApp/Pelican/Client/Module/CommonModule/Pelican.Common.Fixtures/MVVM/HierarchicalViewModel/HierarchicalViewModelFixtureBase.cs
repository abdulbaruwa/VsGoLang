﻿using Pelican.Common.Fixtures.MVVM.Fakes;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    public class HierarchicalViewModelFixtureBase : SingleRunBaseContext<TabControl>
    {
        protected TabControl TabControl;
        protected TabPage Tabpage1;
        protected TabPage Tabpage2;

        protected override TabControl SetupContext()
        {
            TabControl = new TabControl();

            Tabpage1 = new TabPage();
            Tabpage1.View = new object();
            TabControl.AddChild(Tabpage1);

            Tabpage2 = new TabPage();
            Tabpage2.View = new object();
            TabControl.AddChild(Tabpage2);

            return TabControl;
        }

        protected override void Because()
        {
        }
    }
}
