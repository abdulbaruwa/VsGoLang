using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMoveNextFromTabWhereWeAreOnFinalTab : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();

            Sut.SelectedChild = Tabpage2;
        }

        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeTrue()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage2()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage2));
        }
    }
}