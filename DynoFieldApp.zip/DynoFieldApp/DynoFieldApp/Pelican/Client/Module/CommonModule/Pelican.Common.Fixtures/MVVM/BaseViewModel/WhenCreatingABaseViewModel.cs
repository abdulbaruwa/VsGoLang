﻿using System;
using NUnit.Framework;
using Pelican.Common.MVVM;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.BaseViewModel
{
    [TestFixture]
    public class WhenCreatingABaseViewModel : SingleRunBaseContext<ViewModelBase>
    {
        protected override ViewModelBase SetupContext()
        {
            return new ViewModelBase();
        }

        protected override void Because()
        {
        }
        
        [Test]
        public void ViewPropertyShouldBeNull()
        {
            Assert.That(Sut.View, Is.Null);
        }

        [Test]
        public void IsViewEnabledPropertyShouldBeFalse()
        {
            Assert.That(Sut.IsEnabled, Is.EqualTo(false));
        }
    }
}
