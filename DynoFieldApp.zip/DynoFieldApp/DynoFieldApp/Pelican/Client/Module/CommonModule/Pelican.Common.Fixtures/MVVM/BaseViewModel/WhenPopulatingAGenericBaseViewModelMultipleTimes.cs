using NUnit.Framework;
using Pelican.Common.Fixtures.MVVM.Fakes;
using Pelican.Common.MVVM;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.BaseViewModel
{
    [TestFixture]
    public class WhenPopulatingAGenericBaseViewModelMultipleTimes : SingleRunBaseContext<ViewModelBase<string>>
    {
        private string _value;

        protected override ViewModelBase<string> SetupContext()
        {
            return new TabPage();
        }

        protected override void Because()
        {
            _value = "Initial";
            Sut.LoadDataModel(_value);

            //Update the model and reload ViewModel
            _value = "Updated";

            Sut.LoadDataModel(_value);
        }
    
        [Test]
        public void DataModelLoadedCalledWithFirstTimeEqualToFalse()
        {
            Assert.That(((TabPage)Sut).IsFirstTime, Is.EqualTo(false));
        }

        [Test]
        public void DataEntityShouldBeTheSameAsTheOneLoaded()
        {
           Assert.That(Sut.DataModelEntity, Is.SameAs(_value));
        }
    }
}