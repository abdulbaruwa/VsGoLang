using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMovePreviousFromTab : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();

            Sut.SelectedChild = Tabpage2;
        }

        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeTrue()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.True);
        }
    }
}