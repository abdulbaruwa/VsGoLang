using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMovePreviousFromTabWhereThereAreNoMoreEnabledTabs : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage1.IsEnabled = false;
            Sut.SelectedChild = Tabpage2;
        }

        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage2()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage2));
        }
    }
}