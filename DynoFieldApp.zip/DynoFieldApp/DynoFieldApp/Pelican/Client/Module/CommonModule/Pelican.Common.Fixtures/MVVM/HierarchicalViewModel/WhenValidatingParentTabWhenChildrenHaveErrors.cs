using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenValidatingParentTabWhenChildrenHaveErrors : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage2.ErrorMsg = "Field has error.";
            Sut.SelectedChild = Tabpage1;
        }
        
        [Test]
        public void IsValidShouldBeFalse()
        {
            Assert.That(Sut.IsValid, Is.False);
        }
    }
}