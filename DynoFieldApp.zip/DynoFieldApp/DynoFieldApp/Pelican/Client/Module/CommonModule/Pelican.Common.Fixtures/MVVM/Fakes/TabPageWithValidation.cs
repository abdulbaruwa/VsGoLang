using Pelican.Common.MVVM;

namespace Pelican.Common.Fixtures.MVVM.Fakes
{
    public class TabPageWithValidation : ValidatingViewModelBase<string>
    {
        public string ErrorMsg { get; set; }
        
        public override string Error
        {
            get { return ErrorMsg; }
        }
    }
}