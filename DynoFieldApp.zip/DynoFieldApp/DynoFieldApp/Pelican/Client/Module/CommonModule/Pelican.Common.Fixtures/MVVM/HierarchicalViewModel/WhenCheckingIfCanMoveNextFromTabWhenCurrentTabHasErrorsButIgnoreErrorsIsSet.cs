using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMoveNextFromTabWhenCurrentTabHasErrorsButIgnoreErrorsIsSet : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage1.ErrorMsg = "Field has error.";

            Sut.SelectedChild = Tabpage1;
            Sut.CanIgnoreValidationErrorsForNextAndPrevious = true;
        }
        
        [Test]
        public void CanGoNextShouldBeTrue()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void CanGoPreviousShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }
    }
}