﻿using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    public class WhenCheckingCommands : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();

            Sut.SelectedChild = Tabpage1;
        }
        
        [Test]
        public void NextCommandShouldNotBeNull()
        {
            Assert.That(Sut.NextCommand, Is.Not.Null);
        }

        [Test]
        public void PreviousCommandShouldNotBeNull()
        {
            Assert.That(Sut.PreviousCommand, Is.Not.Null);
        }

        [Test]
        public void CanExecuteNextCommandShouldBeTrue()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void CanExecutePreviousCommandShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }
    }
}