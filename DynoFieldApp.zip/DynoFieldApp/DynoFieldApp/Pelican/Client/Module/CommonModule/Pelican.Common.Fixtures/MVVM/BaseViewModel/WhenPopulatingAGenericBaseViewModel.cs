using NUnit.Framework;
using Pelican.Common.Fixtures.MVVM.Fakes;
using Pelican.Common.MVVM;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.BaseViewModel
{
    [TestFixture]
    public class WhenPopulatingAGenericBaseViewModel : SingleRunBaseContext<ViewModelBase<string>>
    {
        private string _value;

        protected override ViewModelBase<string> SetupContext()
        {
            return new TabPage();
        }

        protected override void Because()
        {
            _value = "Initial";
            Sut.LoadDataModel(_value);
        }
        
        [Test]
        public void DataEntityShouldNotBeNull()
        {
            Assert.That(Sut.DataModelEntity, Is.Not.Null);
        }

        [Test]
        public void DataEntityShouldBeTheSameAsTheOneLoaded()
        {
            Assert.That(Sut.DataModelEntity, Is.SameAs(_value));
        }

        [Test]
        public void DataModelLoadedCalledWithFirstTimeEqualToTrue()
        {
            Assert.That(((TabPage)Sut).IsFirstTime, Is.EqualTo(true));
        }
    }
}