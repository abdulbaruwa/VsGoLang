using Pelican.Common.Fixtures.MVVM.Fakes;
using Pelican.TestExtensions;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    public class HierarchicalViewModelWithValidationFixtureBase : SingleRunBaseContext<TabControl>
    {
        protected TabControl TabControl;
        protected TabPageWithValidation Tabpage1;
        protected TabPageWithValidation Tabpage2;

        protected override TabControl SetupContext()
        {
            TabControl = new TabControl();

            Tabpage1 = new TabPageWithValidation();
            Tabpage1.View = new object();
            Tabpage1.ErrorMsg = string.Empty;
            TabControl.AddChild(Tabpage1);

            Tabpage2 = new TabPageWithValidation();
            Tabpage2.View = new object();
            Tabpage1.ErrorMsg = string.Empty;
            TabControl.AddChild(Tabpage2);

            return TabControl;
        }

        protected override void Because()
        {
        }
    }
}