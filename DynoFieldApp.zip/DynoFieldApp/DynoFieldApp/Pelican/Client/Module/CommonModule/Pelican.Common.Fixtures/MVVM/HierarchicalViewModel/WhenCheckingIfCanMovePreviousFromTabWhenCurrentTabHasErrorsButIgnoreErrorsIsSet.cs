using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMovePreviousFromTabWhenCurrentTabHasErrorsButIgnoreErrorsIsSet : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage2.ErrorMsg = "Field has error.";

            Sut.SelectedChild = Tabpage2;
            Sut.CanIgnoreValidationErrorsForNextAndPrevious = true;
        }
        
        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeTrue()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.True);
        }
    }
}