using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenMovingPreviousFromTabWithErrorsButIgnoreErrorsIsSet : HierarchicalViewModelWithValidationFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage2.ErrorMsg = "Field has error.";
            Sut.SelectedChild = Tabpage2;
            Sut.CanIgnoreValidationErrorsForNextAndPrevious = true;

            Sut.PreviousCommand.Execute(null);
        }


        [Test]
        public void CanGoNextShouldBeTrue()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void CanGoPreviousShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage1()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage1));
        }
    }
}