using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCreatingAChildViewModelButNotActivatingParent : HierarchicalViewModelFixtureBase
    {
        [Test]
        public void TheSelectedChildShouldBeTabPage1()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage1));
        }

        [Test]
        public void TheParentControlShouldNotBeActivated()
        {
            Assert.That(Sut.ActivateCount, Is.EqualTo(0));
        }

        [Test]
        public void TheTabPage1ControlShouldNotBeActivated()
        {
            Assert.That(Tabpage1.ActivateCount, Is.EqualTo(0));
        }

        [Test]
        public void TheTabPage2ControlShouldNotBeActivated()
        {
            Assert.That(Tabpage2.ActivateCount, Is.EqualTo(0));
        }
    }
}