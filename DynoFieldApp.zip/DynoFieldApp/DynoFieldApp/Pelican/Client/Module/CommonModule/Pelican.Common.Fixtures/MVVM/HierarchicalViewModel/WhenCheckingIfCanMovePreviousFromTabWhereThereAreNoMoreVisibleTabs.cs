using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCheckingIfCanMovePreviousFromTabWhereThereAreNoMoreVisibleTabs : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
            Tabpage1.IsVisible = false;
            Sut.SelectedChild = Tabpage2;
        }

        [Test]
        public void CanGoNextShouldBeFalse()
        {
            Assert.That(Sut.NextCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void CanGoPreviousShouldBeFalse()
        {
            Assert.That(Sut.PreviousCommand.CanExecute(null), Is.False);
        }
    }
}