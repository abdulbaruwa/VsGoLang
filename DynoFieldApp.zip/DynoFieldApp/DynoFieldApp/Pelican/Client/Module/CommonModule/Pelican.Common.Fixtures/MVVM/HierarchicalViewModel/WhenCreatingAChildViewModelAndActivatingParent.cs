using NUnit.Framework;

namespace Pelican.Common.Fixtures.MVVM.HierarchicalViewModel
{
    [TestFixture]
    public class WhenCreatingAChildViewModelAndActivatingParent : HierarchicalViewModelFixtureBase
    {
        protected override void Because()
        {
            Sut.Activate();
        }

        [Test]
        public void TheSelectedChildShouldBeSet()
        {
            Assert.That(Sut.SelectedChild, Is.Not.Null);
        }

        [Test]
        public void TheSelectedChildShouldBeTabPage1()
        {
            Assert.That(Sut.SelectedChild, Is.EqualTo(Tabpage1));
        }

        [Test]
        public void TheParentControlShouldBeActivated()
        {
            Assert.That(Sut.ActivateCount, Is.EqualTo(1));
        }

        [Test]
        public void TheTabPage1ControlShouldBeActivated()
        {
            Assert.That(Tabpage1.ActivateCount, Is.EqualTo(1));
        }

        [Test]
        public void TheTabPage2ControlShouldNotBeActivated()
        {
            Assert.That(Tabpage2.ActivateCount, Is.EqualTo(0));
        }
    }
}