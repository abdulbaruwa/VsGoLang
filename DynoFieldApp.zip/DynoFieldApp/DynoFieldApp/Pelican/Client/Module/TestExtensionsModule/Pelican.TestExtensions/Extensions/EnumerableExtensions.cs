﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Pelican.TestExtensions.Extensions
{
    public static class EnumerableExtensions
    {
        public static ObservableCollection<T> AsObservableCollection<T>(this IEnumerable<T> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }
            return new ObservableCollection<T>(source);
        }

        public static bool Empty<T>(this IEnumerable<T> source)
        {
            if (source == null) return false;
            return source.Count() > 0;
        }
    }
}

