﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using NUnit.Framework;

namespace Pelican.TestExtensions.Extensions
{
    public class WhenCreatingAnObservableCollectionForAnEnumerable : BaseContext<List<string>>
    {
        private ObservableCollection<string> _collection;

        protected override List<string> SetupContext()
        {
            return new List<string> { "abc", "def", "xyz" };
        }

        protected override void Because()
        {
            _collection = Sut.AsObservableCollection();
        }

        [Test]
        public void ReturnedCollectionIsNotNull()
        {
            _collection.ShouldNotBeNull();
        }

        [Test]
        public void ReturnedCollectionShouldContain3Items()
        {
            _collection.Count.ShouldEqual(Sut.Count);
        }
    }
}
