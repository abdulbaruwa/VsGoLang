﻿using NUnit.Framework;

namespace Pelican.TestExtensions
{
    [Category("UnitTests")]
    public abstract class SingleRunBaseContext<T> : BaseContextBase<T>
    {
        [TestFixtureSetUp]
        public virtual void TestFixtureSetup()
        {
            PerformSetup();
        }
    }
}
