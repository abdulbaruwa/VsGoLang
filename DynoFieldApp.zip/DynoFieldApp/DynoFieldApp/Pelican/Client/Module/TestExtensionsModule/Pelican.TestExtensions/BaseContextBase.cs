﻿using FizzWare.NBuilder;
using FizzWare.NBuilder.PropertyNaming;

namespace Pelican.TestExtensions
{
    public abstract class BaseContextBase<T>
    {
        protected T Sut { get; set; }
        protected abstract T SetupContext();

        protected abstract void Because();

        protected void PerformSetup()
        {
            BuilderSetup.SetDefaultPropertyNamer(new ExtensibleRandomValuePropertyNamer());
            Sut = SetupContext();
            Because();
        }
    }
}