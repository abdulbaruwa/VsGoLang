﻿using Microsoft.Practices.Prism.Regions;
using Rhino.Mocks;

namespace Pelican.TestExtensions.Mocks
{
    public class MockRegionManager : IRegionManager
    {
        public MockRegionManager()
        {
            Regions = CreateRegions();
        }

        public IRegionManager CreateRegionManager()
        {            
            return new MockRegionManager();
        }

        public IRegionCollection Regions { get; set; }
        public IRegion CenterRegion { get; private set; }
        
        private IRegionCollection CreateRegions()
        {
            var regionCollection = MockRepository.GenerateMock<IRegionCollection>();
            CenterRegion = MockRepository.GenerateMock<IRegion>();
            regionCollection.Stub(x => x["CenterRegion"]).Return(CenterRegion);
            return regionCollection;            
        }
    }
}
