﻿using System.Collections.Generic;
using NUnit.Framework;

namespace Pelican.TestExtensions.Extensions
{
    public class WhenUsingAnEnumerableCollection : BaseContext<IEnumerable<string>>
    {
        private List<string> _collection;

        protected override IEnumerable<string> SetupContext()
        {
            return new List<string> {"abc", "def", "xyz"};
        }

        protected override void Because()
        {
            _collection = (List<string>) Sut;
        }

        [Test]
        public void ReturnedCollectionIsNotNull()
        {
            _collection.ShouldNotBeNull();
        }

        [Test]
        public void ShouldReturnTrueIfBaseCollectionHasValues()
        {
            _collection.Empty().ShouldBeTrue();
        }

        [Test]
        public void ShouldReturnFalseIfBaseCollectionHasNoValues()
        {
            _collection.Clear();
            _collection.Empty().ShouldBeFalse();
        }
    }
}